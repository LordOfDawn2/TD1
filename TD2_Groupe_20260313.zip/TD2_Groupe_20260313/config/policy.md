# Security Policy — TD2 Firewall
## gw-fw — NH-LAN ↔ NH-DMZ

---

## 1. Zones and Assets

| Zone | Network | Assets |
|---|---|---|
| LAN (trusted) | 10.10.10.0/24 | client (10.10.10.10) |
| DMZ (semi-trusted) | 10.10.20.0/24 | srv-web (10.10.20.10), sensor-ids (10.10.20.50) |
| Gateway | Both interfaces | gw-fw (10.10.10.1 / 10.10.20.1) |

---

## 2. Allow-List (derived from TD1 flow matrix)

- **ALLOW** LAN → DMZ TCP/80 — HTTP to srv-web (web access)
- **ALLOW** LAN → DMZ TCP/443 — HTTPS to srv-web (secure web access)
- **ALLOW** LAN → DMZ TCP/22 — SSH to srv-web (lab administration)
- **ALLOW** LAN → gw-fw TCP/22 — SSH to gateway (admin access)
- **ALLOW** LAN → DMZ ICMP echo-request — Network diagnostics (rate-limited: 5/sec)
- **ALLOW** ESTABLISHED,RELATED — Stateful return traffic (all chains)
- **ALLOW** loopback (lo) — Local services on gw-fw

---

## 3. Default Posture

- **FORWARD: DROP** — Default deny between zones (no implicit trust)
- **INPUT on gw-fw: DROP** — Gateway self-protection
- **OUTPUT from gw-fw: ACCEPT** — Gateway can initiate connections to both segments

---

## 4. Logging Strategy

- Log all blocked FORWARD traffic — rate-limited 10/min — prefix: `IPT_FWD_DENY`
- Log all blocked INPUT traffic — rate-limited 10/min — prefix: `IPT_IN_DENY`
- Rate limit prevents syslog saturation under flood conditions
- Log entries include: source IP, destination IP, protocol, port

---

## 5. Exception Process

Any new flow must:
1. Be traceable to a service requirement (not convenience)
2. Be added with explicit src/dst/port (no any-any)
3. Be reviewed at next TD session
4. Be documented in this policy.md with date and owner

---

## 6. Out of Scope (this TD)

- DMZ → LAN egress control (lateral movement) — deferred
- HTTPS (TCP/443) — nginx TLS not configured (TD4)
- DNS/NTP — not required in lab environment
- Persistence — iptables-persistent not available; restore manually on reboot
