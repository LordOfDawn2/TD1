#!/bin/bash
# rollback.sh — Emergency iptables flush
# Run from VirtualBox console if locked out
# Restores permissive state in < 30 seconds

echo "[rollback] Flushing all iptables rules..."
iptables -F
iptables -X
iptables -t nat -F
iptables -t nat -X
iptables -t mangle -F
iptables -t mangle -X

echo "[rollback] Setting all policies to ACCEPT..."
iptables -P INPUT ACCEPT
iptables -P FORWARD ACCEPT
iptables -P OUTPUT ACCEPT

echo "[rollback] Done. All traffic is now permitted."
iptables -L -v -n
