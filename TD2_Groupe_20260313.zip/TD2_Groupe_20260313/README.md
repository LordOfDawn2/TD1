# TD2 — Firewall Policy: Contract → Ruleset → Tests → Evidence

**Module:** Network Hardening — ESILV Year 4  
**Date:** March 13, 2026  
**Authors:** Adrien CUINET, Paul GERRARD, Adame FERRE, Gaël LE MOUEL

---

## Topology

```
[client] ──── [gw-fw] ──── [srv-web]
10.10.10.10   10.10.10.1   10.10.20.10
NH-LAN        10.10.20.1   NH-DMZ
              NH-LAN+DMZ
                           [sensor-ids]
                           10.10.20.50
```

| VM | Role | Zone | IP |
|---|---|---|---|
| `gw-fw` | Gateway / Firewall | NH-LAN + NH-DMZ | 10.10.10.1 / 10.10.20.1 |
| `client` | Traffic generator | NH-LAN | 10.10.10.10 |
| `srv-web` | HTTP + SSH target | NH-DMZ | 10.10.20.10 |
| `sensor-ids` | IDS / capture | NH-DMZ | 10.10.20.50 |

---

## How to Reproduce

### 1. Enable IP forwarding on gw-fw
```bash
sudo sysctl -w net.ipv4.ip_forward=1
```

### 2. Apply the ruleset
```bash
sudo iptables-restore < config/firewall_ruleset.txt
sudo iptables -L -v -n   # verify
```

### 3. Run positive tests (from client)
```bash
curl -sI http://10.10.20.10          # P1 — HTTP
ssh user@10.10.20.10 whoami          # P3 — SSH to srv-web
ping -c 2 10.10.20.10                # P4 — ICMP
ssh user@10.10.10.1 whoami           # P6 — SSH to gw-fw
```

### 4. Run negative tests (from client)
```bash
nc -vz -w 3 10.10.20.10 12345        # N1
nc -vz -w 3 10.10.20.10 3306         # N2
nc -vz -w 3 10.10.20.10 23           # N3
```

### 5. Collect evidence
```bash
sudo iptables -L -v -n > evidence/counters_after.txt
sudo journalctl -k --since "1 hour ago" | grep "IPT_FWD_DENY" > evidence/deny_logs.txt
```

### Emergency rollback
```bash
bash config/rollback.sh
```

---

## Security notes
- Default deny on FORWARD and INPUT chains
- All ACCEPT rules are scoped to explicit src/dst/port
- No any-any rules
