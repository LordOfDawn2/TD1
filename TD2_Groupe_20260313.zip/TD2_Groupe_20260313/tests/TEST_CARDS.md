# TEST_CARDS.md — TD2 Firewall Policy

---

## TD2-T01 — Allowed flows from matrix pass (HTTP)

**Claim:** HTTP (TCP/80) from LAN to srv-web is forwarded by gw-fw.

**Positive test:**
```bash
curl -sI http://10.10.20.10 | head -5
# Expected: HTTP/1.1 200 OK
```

**Negative test:** N/A (covered by T02)

**Evidence:** `evidence/counters_after.txt`, `tests/commands.txt`

---

## TD2-T02 — Default deny blocks unlisted traffic

**Claim:** Traffic to ports not in the allow-list is dropped by the FORWARD chain.

**Positive test:** N/A

**Negative test:**
```bash
nc -vz -w 3 10.10.20.10 12345
# Expected: connection timeout (not refused — DROP policy)
```

**Evidence:** `evidence/deny_logs.txt`

---

## TD2-T03 — Denied traffic produces telemetry

**Claim:** Blocked forwarded packets generate log entries on gw-fw with prefix `IPT_FWD_DENY`.

**Positive test:**
```bash
# After running negative tests, on gw-fw:
sudo journalctl -k --since "10 minutes ago" | grep "IPT_FWD_DENY"
# Expected: log entries with SRC/DST/PROTO/DPT fields
```

**Negative test:** Without negative test traffic, no `IPT_FWD_DENY` entries appear.

**Evidence:** `evidence/deny_logs.txt`

---

## TD2-T04 — Ruleset is reversible

**Claim:** `rollback.sh` restores a permissive state within 30 seconds.

**Positive test:**
```bash
# From VirtualBox console on gw-fw:
bash ~/TD2/config/rollback.sh
# Expected: all policies set to ACCEPT, all traffic permitted
sudo iptables -L | grep "policy ACCEPT"
```

**Negative test:** N/A

**Evidence:** `config/rollback.sh`

---

## TD2-T05 — Admin SSH access preserved at all times

**Claim:** SSH from LAN to gw-fw (INPUT chain) works at all times, including after default deny.

**Positive test:**
```bash
ssh -o ConnectTimeout=3 user@10.10.10.1 whoami
# Expected: user
```

**Negative test:**
```bash
# SSH from DMZ to gw-fw (not in allow-list)
nc -vz -w 3 10.10.20.1 22
# Expected: timeout (INPUT DROP from DMZ)
```

**Evidence:** `tests/commands.txt`

---

## TD2-T06 — Rules are minimal and scoped (no any-any)

**Claim:** Each rule in the ruleset specifies explicit source, destination, and port. No wildcard rule exists.

**Positive test:**
```bash
cat config/firewall_ruleset.txt | grep -v "^#" | grep -v "^$"
# Expected: all FORWARD ACCEPT rules have -s, -d, and --dport
```

**Negative test:** No rule matches `0.0.0.0/0` as source or destination in ACCEPT rules.

**Evidence:** `config/firewall_ruleset.txt`

---

## TD2-T07 — Counter analysis shows enforcement

**Claim:** The deny rule counter increments after negative tests, proving traffic is intercepted.

**Positive test:**
```bash
# Compare counters before and after negative tests:
diff evidence/counters_before.txt evidence/counters_after.txt
# Expected: packet/byte counters higher in counters_after.txt for LOG/DROP rules
```

**Negative test:** If counters don't increment, traffic is not reaching gw-fw (routing issue).

**Evidence:** `evidence/counters_before.txt`, `evidence/counters_after.txt`
