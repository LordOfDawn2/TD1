# Appendix — Failure Modes

| ID | Failure | Symptom | Fix Applied |
|---|---|---|---|
| FM-01 | IP forwarding disabled | LAN↔DMZ traffic silently blocked | `sysctl -w net.ipv4.ip_forward=1` on gw-fw |
| FM-02 | DROP before allow rules | Immediate total lockout | Add essential allow rules BEFORE setting DROP policy |
| FM-03 | Loopback forgotten | Local services on gw-fw fail | `-A INPUT -i lo -j ACCEPT` added first |
| FM-04 | Stateful rule missing | Return traffic blocked (one-way flows) | Added `ctstate ESTABLISHED,RELATED` on both chains |
| FM-05 | Rules on wrong chain | Rules have no effect | FORWARD = transit traffic; INPUT = traffic to gw-fw |
| FM-06 | Logging without rate limit | Syslog saturation under flood | Added `--limit 10/min` on all LOG rules |
| FM-07 | Rules lost on reboot | Firewall inactive after restart | `iptables-restore < config/firewall_ruleset.txt` at startup |
| FM-08 | NAT confusion | Unexpected address translation | No NAT rules added — not required in this lab |
