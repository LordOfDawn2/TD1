# TD3 — Report : IDS/IPS Detection Engineering

**Module:** Network Hardening — ESILV 4ème année  
**Date:** 2026-04-09  
**Groupe:** _____

---

## 1. Topologie et placement du capteur

| VM | Rôle | Zone | IP |
|---|---|---|---|
| gw-fw | Gateway / Trust Boundary | NH-LAN + NH-DMZ | 10.10.10.1 / 10.10.20.1 |
| client | Traffic generator | NH-LAN | 10.10.10.10 |
| srv-web | Target (HTTP, SSH) | NH-DMZ | 10.10.20.10 |
| sensor-ids | Suricata IDS | NH-DMZ | 10.10.20.50 |

**Interface de capture :** `enp0s3` sur sensor-ids — connectée au segment NH-DMZ en mode promiscuous.

**Ce que le capteur voit :**
- Tout le trafic client → srv-web (après passage par gw-fw)
- Trafic de retour srv-web → client
- ARP et broadcasts DMZ

**Ce que le capteur ne voit pas :**
- Trafic LAN-interne (sensor-ids n'a pas de NIC sur NH-LAN)
- Payloads TLS chiffrés (HTTP en clair uniquement)
- Trafic bloqué par gw-fw avant d'atteindre la DMZ (si TD2 actif)

---

## 2. Ce qui a été détecté

### Trigger déterministe — nmap scan
**Commande :** `nmap -sS -sV -p 1-1000 10.10.20.10` depuis client (10.10.10.10)

**Alerte générée :**
```
04/09/2026-23:14:28 [**] [1:2024364:5] ET SCAN Possible Nmap User-Agent Observed [**]
[Classification: Web Application Attack] [Priority: 1]
{TCP} 10.10.10.10 -> 10.10.20.10:80
```

**Analyse :** Suricata détecte le User-Agent HTTP caractéristique de nmap (-sV). 4 alertes générées pour un scan de 1000 ports — confirms que le moteur de détection est opérationnel.

**Note TD2 :** Sans firewall TD2 actif, tous les probes atteignent la DMZ. Avec TD2 actif, seuls les ports 22/80/443 passeraient → ~3 alertes maximum. C'est la défense en couches en action.

---

## 3. Règle custom

**Fichier :** `config/local.rules`

```
alert http $HOME_NET any -> $HOME_NET 80 (msg:"TD3 CUSTOM - HTTP request to /admin detected"; flow:to_server,established; http.uri; content:"/admin"; sid:9000001; rev:1; classtype:policy-violation;)
```

**Explication des keywords :**

| Keyword | Rôle |
|---|---|
| `alert http` | Détection couche application HTTP |
| `$HOME_NET any -> $HOME_NET 80` | Scope : trafic interne vers port 80 uniquement |
| `flow:to_server,established` | Direction client→serveur dans session TCP établie |
| `http.uri; content:"/admin"` | Match sur l'URI HTTP (dot notation Suricata 7.x) |
| `sid:9000001; rev:1` | Identifiant unique + révision |
| `classtype:policy-violation` | Classification pour triage |

**Test positif :** `curl http://10.10.20.10/admin` → alerte sid:9000001 ✅  
**Test négatif :** `curl http://10.10.20.10/index.html` → aucune alerte ✅

**Alerte générée :**
```
04/09/2026-23:40:11 [**] [1:9000001:1] TD3 CUSTOM - HTTP request to /admin detected [**]
[Classification: Potential Corporate Privacy Violation] [Priority: 1]
{TCP} 10.10.10.10:55216 -> 10.10.20.10:80
```

---

## 4. Action de tuning — before/after

**Règle bruyante :** sid:2024364 (ET SCAN Possible Nmap User-Agent Observed)

**Problème :** 4 alertes générées pour un seul scan nmap depuis le client de lab — trafic connu et attendu dans ce contexte.

**Action appliquée :** Suppression pour la source connue 10.10.10.10

**Fichier :** `/etc/suricata/threshold.config`
```
suppress gen_id 1, sig_id 2024364, track by_src, ip 10.10.10.10
```

| | Avant tuning | Après tuning |
|---|---|---|
| Alertes sid:2024364 | 4 | 0 |
| Commande test | `nmap -sS -p 1-1000 10.10.20.10` | identique |

**Justification :**
- 10.10.10.10 est le client du lab — ses scans sont des tests connus et documentés
- La suppression est **par source** (`track by_src`) → toute autre IP inconnue générera toujours des alertes
- Risque résiduel : si 10.10.10.10 est compromis, ses scans passeront inaperçus → à réévaluer en production

---

## 5. Limitations

| Limitation | Impact | Mitigation possible |
|---|---|---|
| TLS non configuré | Payloads HTTP visibles → règles de contenu efficaces mais risque interception | Configurer HTTPS sur srv-web (TD4) |
| Sensor DMZ uniquement | Trafic LAN-interne invisible | Ajouter sensor sur NH-LAN |
| TD2 non implémenté | Pas de layered defense | Implémenter firewall TD2 |
| Suppress trop large | Scans depuis 10.10.10.10 invisibles | Utiliser threshold type limit en production |
| Asymétric routing | Possible si routes non symétriques | Vérifier que sensor voit les deux directions |
