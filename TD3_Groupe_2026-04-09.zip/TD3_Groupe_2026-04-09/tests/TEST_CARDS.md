# TEST_CARDS.md — TD3 IDS Detection Engineering

---

## TD3-T01 — Sensor voit le trafic DMZ en mode promiscuous

**Claim :** sensor-ids en mode promiscuous sur enp0s3 capture le trafic HTTP et ICMP entre client et srv-web.

**Preconditions :**
- sensor-ids connecté au segment NH-DMZ
- Mode promiscuous activé (`ip link set enp0s3 promisc on`)
- VirtualBox : Adapter → Advanced → Promiscuous Mode → Allow All

**Test method :**
- Positif : `curl http://10.10.20.10` depuis client + `tcpdump -i enp0s3 -c 10 host 10.10.20.10` sur sensor-ids → paquets visibles
- Négatif : désactiver promiscuous → sensor ne voit que son propre trafic

**Expected result :** ICMP echo request/reply + ARP visibles dans tcpdump

**Result :** ✅ PASS

**Evidence pointer :** evidence/visibility_proof.txt

---

## TD3-T02 — Règle communautaire se déclenche sur scan nmap

**Claim :** Un scan nmap depuis client génère une alerte sid:2024364 sur sensor-ids.

**Preconditions :**
- Suricata actif avec règles ET Open chargées (65356 règles)
- Interface enp0s3 configurée dans suricata.yaml

**Test method :**
- Positif : `nmap -sS -sV -p 1-1000 10.10.20.10` → alerte sid:2024364 dans fast.log
- Négatif : `curl http://10.10.20.10` → pas d'alerte sid:2024364

**Expected result :** `[1:2024364:5] ET SCAN Possible Nmap User-Agent Observed`

**Result :** ✅ PASS — 4 alertes générées

**Evidence pointer :** evidence/alerts_excerpt.txt

---

## TD3-T03 — Règle custom déclenche sur /admin

**Claim :** La règle custom sid:9000001 se déclenche quand client accède à /admin sur srv-web.

**Preconditions :**
- Suricata actif avec /etc/suricata/rules/local.rules chargé
- nginx actif sur srv-web port 80

**Test method :**
- Positif : `curl http://10.10.20.10/admin` → alerte sid:9000001 dans fast.log
- Négatif : `curl http://10.10.20.10/index.html` → aucune alerte sid:9000001

**Expected result :** `[1:9000001:1] TD3 CUSTOM - HTTP request to /admin detected`

**Result :** ✅ PASS

**Evidence pointer :** evidence/alerts_excerpt.txt

---

## TD3-T04 — Règle custom est scopée et versionnée

**Claim :** La règle custom spécifie HOME_NET, port 80, direction du flux, et possède sid/rev.

**Preconditions :** Fichier /etc/suricata/rules/local.rules présent

**Test method :**
- Vérifier présence de : `$HOME_NET`, `-> $HOME_NET 80`, `flow:to_server`, `http.uri`, `sid:9000001`, `rev:1`
- Vérifier absence de règles trop larges (any any)

**Expected result :** Tous les champs requis présents, règle sur une seule ligne

**Result :** ✅ PASS

**Evidence pointer :** config/local.rules

---

## TD3-T05 — Tuning réduit le bruit sans cacher les vraies menaces

**Claim :** Après suppression de sid:2024364 pour 10.10.10.10, le count d'alertes passe de 4 à 0 pour cette source, mais une source inconnue génèrerait toujours des alertes.

**Preconditions :**
- threshold.config avec suppress gen_id 1, sig_id 2024364, track by_src, ip 10.10.10.10

**Test method :**
- Before : `nmap -sS -p 1-1000 10.10.20.10` → grep "2024364" → 4
- After : même commande → grep "2024364" → 0
- Validation : `track by_src` garantit que seule 10.10.10.10 est supprimée

**Expected result :** BEFORE=4, AFTER=0

**Result :** ✅ PASS

**Evidence pointer :** evidence/before_after_counts.txt

---

## TD3-T06 — Les preuves sont reproductibles

**Claim :** Relancer les commandes documentées sur la même topologie produit les mêmes alertes.

**Preconditions :**
- Même topologie 4-VM
- Suricata configuré avec même suricata.yaml et local.rules
- Règles ET Open identiques

**Test method :**
- Relancer `tests/commands.txt` séquentiellement
- Vérifier que fast.log contient sid:2024364 et sid:9000001

**Expected result :** Alertes identiques aux screenshots de preuve

**Result :** ✅ PASS (reproductible)

**Evidence pointer :** tests/commands.txt, evidence/alerts_excerpt.txt

---

## TD3-T07 (bonus) — Justification du placement du capteur

**Claim :** Placer le capteur sur NH-DMZ donne visibilité sur les attaques LAN→DMZ mais pas sur le trafic LAN-interne.

**Preconditions :** sensor-ids uniquement connecté à NH-DMZ

**Test method :**
- Positif : trafic client → srv-web visible dans tcpdump sur enp0s3
- Négatif : trafic LAN-interne (client → gw-fw uniquement) non visible sur sensor-ids

**Expected result :** Seul le trafic DMZ est capturé

**Result :** ✅ PASS — validé par architecture réseau

**Evidence pointer :** config/interface_selection.txt
