# Failure Modes — TD3

## FM01 — internet_on.sh absent sur sensor-ids
**Problème :** Le script internet_on.sh n'existe pas sur sensor-ids.
**Symptôme :** `bash: ./internet_on.sh: No such file or directory`
**Résolution :** Configurer manuellement l'interface bridged :
```bash
sudo ip link set enp0s8 up
sudo ip addr add 192.168.1.100/24 dev enp0s8
sudo ip route add default via 192.168.1.1 dev enp0s8
echo "nameserver 8.8.8.8" | sudo tee -a /etc/resolv.conf
```

## FM02 — Dossier logs Suricata non accessible en écriture
**Problème :** /var/log/suricata/ n'est pas writable après restart.
**Symptôme :** `The logging directory is not writable`
**Résolution :** `sudo chmod 777 /var/log/suricata/`

## FM03 — Règle custom sur deux lignes dans nano
**Problème :** Copier-coller crée un retour à la ligne dans la règle.
**Symptôme :** `Error: detect: error parsing signature`
**Résolution :** Utiliser bash -c avec echo pour écrire la règle en une seule ligne :
```bash
sudo bash -c 'echo "alert http ..." > /etc/suricata/rules/local.rules'
```

## FM04 — threshold.conf vs threshold.config
**Problème :** suricata.yaml pointe vers threshold.config mais fichier créé en .conf
**Symptôme :** Threshold n'est pas appliqué
**Résolution :** Vérifier `grep "threshold-file" /etc/suricata/suricata.yaml` et nommer le fichier en conséquence.

## FM05 — Règle custom chargée dans mauvaise section yaml
**Problème :** local.rules ajouté dans section #include au lieu de rule-files
**Symptôme :** Suricata échoue au démarrage (exit-code)
**Résolution :** Éditer suricata.yaml et placer `- /etc/suricata/rules/local.rules` sous `rule-files:`

## FM06 — HOME_NET reste "any" après sed
**Problème :** Le sed ne trouve pas la bonne ligne à remplacer
**Symptôme :** HOME_NET toujours "any" dans grep
**Résolution :** Éditer manuellement avec nano et chercher HOME_NET
