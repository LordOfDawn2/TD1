# TD3 — IDS/IPS Detection Engineering with Suricata

**Module:** Network Hardening — ESILV 4ème année  
**Date:** 2026-04-09  
**Groupe:** _____

---

## Membres et rôles

| Membre | Rôle |
|---|---|
| _____ | Operator (IDS) |
| _____ | Evidence keeper |
| _____ | Reporter |

---

## Topologie

| VM | Rôle | Zone | IP |
|---|---|---|---|
| gw-fw | Gateway / Trust Boundary | NH-LAN + NH-DMZ | 10.10.10.1 / 10.10.20.1 |
| client | Traffic generator | NH-LAN | 10.10.10.10 |
| srv-web | Target (HTTP, SSH) | NH-DMZ | 10.10.20.10 |
| sensor-ids | Suricata IDS | NH-DMZ | 10.10.20.50 |

---

## Ce qui a été fait

- Installation Suricata 7.0.3 sur sensor-ids
- Configuration HOME_NET : 10.10.10.0/24 + 10.10.20.0/24
- Interface de capture : enp0s3 (NH-DMZ) en mode promiscuous
- Téléchargement règles ET Open (65 356 règles)
- Trigger déterministe : nmap -sS -sV -p 1-1000 → sid:2024364
- Règle custom : sid:9000001 (HTTP /admin detection)
- Tuning : suppress sid:2024364 pour source 10.10.10.10 (before: 4, after: 0)

## Note TD2
TD2 (firewall) non implémenté — Suricata voit tout le trafic DMZ sans filtrage préalable. Avec TD2 actif, le nombre d'alertes nmap serait réduit (~3 au lieu de 4+) car seuls les ports autorisés atteindraient la DMZ.

---

## Limitations connues

- TLS non configuré sur srv-web → payloads HTTP visibles en clair
- Sensor sur DMZ uniquement → trafic LAN-interne invisible
- TD2 firewall non actif → pas de layered defense
- Trafic firewall-dropped invisible pour sensor-ids
