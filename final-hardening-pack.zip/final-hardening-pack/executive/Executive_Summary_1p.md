# Executive Summary

## Top 3 Risks
- **Data Interception**: Unencrypted HTTP traffic between the LAN and the DMZ leaves sensitive information vulnerable to interception and eavesdropping.
- **Unauthorised Access**: The absence of strict access controls and default deny policies increases the risk of unauthorised access to critical systems.
- **Compliance Gaps**: Inadequate logging and monitoring can lead to non-compliance with security standards and delay incident response.

## 5 Controls Implemented
- Implementation of TLS 1.2+ for all web traffic to prevent data interception and ensure confidentiality.
- Implementation of default deny policies on the firewall’s FORWARD and INPUT chains to block unauthorised traffic.
- Logging with rate limiting for blocked traffic to ensure traceability without overloading the system logs.
- Configuration of intrusion detection rules to alert in the event of suspicious activity and potential attacks.
- Securing remote access by disabling the root login and restricting SSH access to specific users.

## Residual Risks
- **Lateral Movement**: There are no restrictions in place to limit traffic flows from the DMZ to the LAN, allowing for potential lateral movement within the network.
- **DNS/NTP Vulnerabilities**: There are no specific rules for DNS/NTP traffic, which could be exploited for attacks such as DNS spoofing.
- **Rule Persistence**: iptables rules are not persistent after a reboot without manual intervention.

## Next Steps
- **30 Days**: Implement quick wins such as monitoring, patching and key rotation.
- **60 Days**: Focus on architectural improvements such as network segmentation and WAF configuration.
- **90 Days**: Establish governance and automation via Infrastructure as Code (IaC) and CI checks.