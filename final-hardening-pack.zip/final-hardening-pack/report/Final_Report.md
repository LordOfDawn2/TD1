| Claim ID | Claim | Control location | Proof artifact |
|---|---|---|---|
| 1 | All HTTP traffic from LAN to DMZ on TCP/80 is allowed for web access to srv-web. | gw-fw | counters_before.txt |
| 2 | All HTTPS traffic from LAN to DMZ on TCP/443 is allowed for secure web access to srv-web. | gw-fw | counters_before.txt |
| 3 | SSH access from LAN to DMZ on TCP/22 is allowed for lab administration to srv-web. | gw-fw | |
| 4 | SSH access from LAN to gw-fw on TCP/22 is allowed for admin access to the gateway. | gw-fw | |
| 5 | ICMP echo requests from LAN to DMZ are allowed for network diagnostics (rate-limited). | gw-fw | deny_logs.txt |
| 6 | Established/related return traffic is allowed for stateful communication. | gw-fw | |
| 7 | Default deny policy is applied on FORWARD and INPUT chains for all other traffic. | gw-fw | deny_logs.txt |
| 8 | All blocked FORWARD traffic is logged with a rate limit of 10/min (prefix: IPT_FWD_DENY). | gw-fw | |
| 9 | All blocked INPUT traffic is logged with a rate limit (prefix: IPT_IN_DENY). | gw-fw | |
| 10 | All authorised flows (HTTP, SSH, ICMP) work correctly as verified by positive tests. | gw-fw | |
| 11 | All unauthorised flows are blocked as verified by negative tests. | gw-fw | |
| 12 | No any-any rules are present; all rules specify precise source, destination, and port. | gw-fw | firewall_ruleset.txt |
| 13 | Rate-limited logging prevents syslog saturation. | gw-fw | deny_logs.txt |
| 14 | sensor-ids in promiscuous mode on enp0s3 captures HTTP and ICMP traffic between client and srv-web. | sensor-ids | alerts_excerpt.txt |
| 15 | A nmap scan from the client generates an alert sid:2024364 on sensor-ids. | sensor-ids | alerts_excerpt.txt |
| 16 | The custom rule sid:9000001 triggers when the client accesses /admin on srv-web. | sensor-ids | alerts_excerpt.txt |
| 17 | The custom rule specifies HOME_NET, port 80, flow direction, and has sid/rev. | sensor-ids | custom_rules.rules |
| 18 | After suppressing sid:2024364 for 10.10.10.10, the alert count drops from 4 to 0 for this source. | sensor-ids | alerts_excerpt.txt |
| 19 | Re-running documented commands on the same topology produces the same alerts. | sensor-ids | |
| 20 | Placing the sensor on NH-DMZ provides visibility on LAN→DMZ attacks but not on LAN-internal traffic. | sensor-ids | |
| 21 | The baseline endpoint offers CBC-based and non-forward-secrecy cipher suites. | sensor-ids | nmap_ciphers.txt |
| 22 | TLS 1.0 and TLS 1.1 are not offered after hardening. TLS 1.3 is now available. | srv-web | nmap_ciphers.txt |
| 23 | After hardening, all negotiated cipher suites use ECDHE key exchange (forward secrecy). | srv-web | |
| 24 | Certificate subject, validity, and chain match the documented self-signed lab model. | srv-web | |
| 25 | Rate limiting zone is configured on /api endpoint (limit_req_zone rate=1r/s). | srv-web | |
| 26 | Requests with user-agent matching sqlmap or nikto are blocked with 403. | srv-web | filter_test.txt |
| 27 | Legitimate requests without malicious user-agent are not blocked. | srv-web | filter_test.txt |
| 28 | Strict-Transport-Security header is present in responses after hardening. | srv-web | |
