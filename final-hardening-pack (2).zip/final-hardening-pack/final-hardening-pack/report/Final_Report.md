# Final Report — Network Hardening Pack
## ESILV Year 4 — TD1 to TD5 Consolidation

**Authors:** Adrien CUINET, Paul GERRARD, Adame FERRE, Gaël LE MOUEL  
**Date:** April 10, 2026  
**Module:** Network Hardening

---

## 1. Executive Summary

This document consolidates the hardening work performed across TD1–TD5 into an auditable, reproducible security posture for a two-site virtualized lab network. The environment spans a LAN zone (trusted), a DMZ zone (semi-trusted), and a WAN segment connecting two gateways via IPsec VPN.

---

## 2. Claims Table

Every claim below is testable, points to a configuration artifact, and is linked to a proof artifact.

| Claim ID | Claim | Control location | Test | Proof artifact |
|---|---|---|---|---|
| **C-01** | Only HTTP (TCP/80), HTTPS (TCP/443), SSH (TCP/22), and rate-limited ICMP from LAN reach the DMZ web service | `controls/firewall/firewall_ruleset.txt` | R1_firewall.sh — positive + negative | `evidence/after/counters_after.txt`, `evidence/after/deny_logs.txt` |
| **C-02** | All traffic not in the allow-list is dropped and logged with prefix `IPT_FWD_DENY` | `controls/firewall/firewall_ruleset.txt` | R1_firewall.sh — N1 to N6 | `evidence/after/deny_logs.txt` |
| **C-03** | SSH to siteB-srv uses ED25519 key-only authentication — password auth disabled | `controls/remote_access/sshd_config_excerpt.txt` | R3_remote_access.sh — positive key test + negative password test | `evidence/after/authlog_excerpt.txt` |
| **C-04** | Root login via SSH to siteB-srv is blocked | `controls/remote_access/sshd_config_excerpt.txt` | R3_remote_access.sh — negative root test | `evidence/after/authlog_excerpt.txt` |
| **C-05** | Only user `admin1` can SSH to siteB-srv (AllowUsers enforced) | `controls/remote_access/sshd_config_excerpt.txt` | R3_remote_access.sh — negative other-user test | `evidence/after/authlog_excerpt.txt` |
| **C-06** | All cross-site traffic (LAN ↔ DMZ) is encrypted via IPsec ESP — no cleartext on WAN | `controls/remote_access/ipsec_siteA.conf`, `controls/remote_access/ipsec_siteB.conf` | R3_remote_access.sh — IPsec status check | `evidence/after/ipsec_status.txt`, `evidence/after/tunnel_ping.txt` |
| **C-07** | IPsec tunnel is scoped to 10.10.10.0/24 ↔ 10.10.20.0/24 only — no 0.0.0.0/0 tunnelling | `controls/remote_access/ipsec_siteA.conf` | Manual: grep leftsubnet/rightsubnet | `controls/remote_access/ipsec_siteA.conf` |
| **C-08** | TLS minimum version on srv-web is TLS 1.2; TLS 1.0 and 1.1 are rejected | `controls/tls_edge/` | R2_tls.sh — TLS version checks | `evidence/after/tls_audit.txt` |
| **C-09** | Weak cipher suites (RC4, NULL, export) are disabled on srv-web | `controls/tls_edge/` | R2_tls.sh — cipher suite checks | `evidence/after/tls_audit.txt` |
| **C-10** | IDS sensor (sensor-ids) is placed on NH-DMZ in promiscuous mode and detects suspicious flows | `controls/ids/` | R4_detection.sh — test flow + alert check | `evidence/after/ids_alerts.txt` |
| **C-11** | Gateway gw-fw enforces INPUT DROP — only SSH from LAN is permitted to the gateway itself | `controls/firewall/firewall_ruleset.txt` | R1_firewall.sh — SSH to gw-fw positive + ICMP to gw-fw blocked | `evidence/after/counters_after.txt` |
| **C-12** | Firewall ruleset is reversible in under 30 seconds via rollback script | `controls/firewall/rollback.sh` | Manual: bash rollback.sh + iptables -L | `controls/firewall/rollback.sh` |

---

## 3. Architecture Overview

```
[siteA-client]──────[siteA-gw (gw-fw)]══════WAN (IPsec ESP)══════[siteB-gw (sensor-ids)]──────[siteB-srv (srv-web)]
 10.10.10.10          10.10.10.1                                    10.10.20.1                    10.10.20.10
 NH-LAN               10.10.99.1                                    10.10.99.2                    NH-DMZ
                       NH-LAN + NH-WAN                              NH-WAN + NH-DMZ
                       iptables firewall                             strongSwan IKEv2
                       strongSwan IKEv2                             [sensor-ids 10.10.20.50]
```

**Zone trust model:**
- NH-LAN (10.10.10.0/24) — Trusted
- NH-DMZ (10.10.20.0/24) — Semi-trusted
- NH-WAN (10.10.99.0/24) — Untrusted (encrypted by IPsec)

---

## 4. Controls Implemented

### TD2 — Firewall Policy
- Default deny on FORWARD and INPUT chains
- Allow-list: HTTP/80, HTTPS/443, SSH/22 (LAN→DMZ), ICMP (rate-limited)
- Rate-limited deny logging (IPT_FWD_DENY / IPT_IN_DENY)
- Rollback script for emergency recovery

### TD3 — IDS/Detection
- sensor-ids (10.10.20.50) placed on NH-DMZ in promiscuous mode
- Suricata deployed for traffic analysis
- Tuned rules for lab environment

### TD4 — TLS Hardening
- TLS 1.2 minimum enforced on srv-web
- TLS 1.3 enabled
- Weak suites (RC4, NULL, export) disabled
- HSTS header configured

### TD5 — SSH Hardening + IPsec VPN
- Key-only SSH (ED25519), password auth disabled
- PermitRootLogin no, AllowUsers admin1
- IKEv2 site-to-site VPN (AES-256/SHA-256/MODP-2048)
- Tunnel scoped to LAN↔DMZ subnets only
- Persistent config via netplan + systemd

---

## 5. Known Limitations and Residual Risks

| Risk | Description | Mitigation planned |
|---|---|---|
| PSK-based VPN | IPsec uses PSK — no certificate revocation | Migrate to X.509 PKI (30-day plan) |
| No MFA on SSH | ED25519 key sufficient — no second factor | Add TOTP/FIDO2 |
| No DMZ→LAN egress | Lateral movement not restricted | Add FORWARD rules for DMZ→LAN |
| iptables-persistent | Rules lost on reboot without restore | Install iptables-persistent or add to rc.local |
| Local logs only | auth.log and syslog not centralised | Forward to SIEM |
| TLS self-signed cert | No trusted CA — browsers warn | Deploy Let's Encrypt or internal CA |

---

## 6. Test Suite Summary

| Script | Controls tested | Critical |
|---|---|---|
| `R1_firewall.sh` | Firewall allow-list + default deny | Yes |
| `R2_tls.sh` | TLS version + cipher suites | No |
| `R3_remote_access.sh` | SSH hardening + IPsec tunnel | Yes |
| `R4_detection.sh` | IDS sensor reachability + alert generation | No |

Run all tests: `bash tests/regression/run_all.sh`

---

## 7. Evidence Index

| File | Content | Claim |
|---|---|---|
| `evidence/after/counters_after.txt` | iptables counters post-test | C-01, C-02, C-11 |
| `evidence/after/deny_logs.txt` | IPT_FWD_DENY kernel log entries | C-02 |
| `evidence/after/authlog_excerpt.txt` | SSH accept/deny audit log | C-03, C-04, C-05 |
| `evidence/after/ipsec_status.txt` | ipsec statusall output | C-06 |
| `evidence/after/tunnel_ping.txt` | Ping + ESP capture cross-site | C-06 |
| `evidence/after/tls_audit.txt` | openssl s_client TLS checks | C-08, C-09 |
| `evidence/after/ids_alerts.txt` | Suricata alert log excerpt | C-10 |
