# Risk Register — Network Hardening Lab

| ID | Risk | Likelihood | Impact | Current Mitigation | Residual Risk | Owner |
|---|---|---|---|---|---|---|
| R-01 | PSK compromise (VPN) | Medium | High | PSK stored only on gateways | Medium — migrate to PKI | SecOps |
| R-02 | SSH key theft | Low | High | ED25519 key, no password, AllowUsers | Medium — add MFA | SecOps |
| R-03 | Lateral movement (DMZ→LAN) | Medium | High | None — not yet implemented | High | Infra |
| R-04 | Firewall rules lost on reboot | High | High | Manual restore procedure | Medium — add persistence | Sysadmin |
| R-05 | No centralised logging | High | Medium | Local logs on each VM | High — blind spots | SecOps |
| R-06 | Self-signed TLS cert | High | Low | Accepted for lab — browsers warn | Low (lab context) | Infra |
| R-07 | IDS false negative | Medium | Medium | Tuned Suricata rules | Medium | SecOps |
| R-08 | No MFA on SSH | Medium | High | Key-only auth | Medium | SecOps |
