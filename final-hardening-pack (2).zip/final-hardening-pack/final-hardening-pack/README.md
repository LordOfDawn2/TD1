# Final Hardening Pack — Network Hardening TD6

**ESILV Year 4 | April 2026**  
**Authors:** Adrien CUINET, Paul GERRARD, Adame FERRE, Gaël LE MOUEL

---

## Quick Start

```bash
# Run the full regression suite (from siteA-client)
bash tests/regression/run_all.sh

# Results stored in:
# tests/regression/results/<timestamp>/
```

---

## Repository Structure

```
final-hardening-pack/
  README.md                          ← This file
  executive/
    Executive_Summary_1p.md          ← 1-page brief for management
  architecture/
    reachability_matrix.csv          ← Flow matrix
    assumptions.md                   ← Lab assumptions
  controls/
    firewall/                        ← TD2 iptables ruleset + policy + rollback
    ids/                             ← TD3 Suricata config
    remote_access/                   ← TD5 SSH + IPsec configs
    tls_edge/                        ← TD4 TLS configuration
  evidence/
    baseline/                        ← Pre-hardening counters
    after/                           ← Post-hardening evidence
  tests/
    TEST_CARDS.md                    ← All test cards (TD2–TD5)
    regression/
      run_all.sh                     ← Master runner
      R1_firewall.sh                 ← Firewall policy tests
      R2_tls.sh                      ← TLS hardening tests
      R3_remote_access.sh            ← SSH + VPN tests
      R4_detection.sh                ← IDS detection tests
      results/                       ← Test outputs (timestamped)
  report/
    Final_Report.md                  ← Claims table + full analysis
    Risk_Register.md                 ← Risk register
    30_60_90_Plan.md                 ← Action plan
```

---

## Claims Summary

| Claim | Control | Status |
|---|---|---|
| C-01: Only allowed flows reach DMZ | Firewall | ✅ Verified |
| C-02: Unlisted traffic is dropped + logged | Firewall | ✅ Verified |
| C-03: SSH key-only auth on siteB-srv | SSH hardening | ✅ Verified |
| C-04: Root login blocked | SSH hardening | ✅ Verified |
| C-05: AllowUsers enforced | SSH hardening | ✅ Verified |
| C-06: Cross-site traffic encrypted (ESP) | IPsec VPN | ✅ Verified |
| C-07: VPN tunnel scoped to subnets | IPsec VPN | ✅ Verified |
| C-08: TLS 1.2+ enforced | TLS hardening | ✅ Verified |
| C-09: Weak ciphers disabled | TLS hardening | ✅ Verified |
| C-10: IDS detects suspicious flows | Suricata | ✅ Verified |
| C-11: Gateway INPUT DROP enforced | Firewall | ✅ Verified |
| C-12: Rollback script works | Firewall | ✅ Verified |

---

## Topology

```
[siteA-client]──[siteA-gw]══IPsec ESP══[siteB-gw]──[siteB-srv]
 10.10.10.10     10.10.10.1              10.10.20.1   10.10.20.10
 NH-LAN          10.10.99.1              10.10.99.2   NH-DMZ
                                        [sensor-ids]
                                         10.10.20.50
```
