# SSH Hardening — siteB-srv

## Changes applied

| Parameter | Before | After | Justification |
|---|---|---|---|
| `PasswordAuthentication` | yes (cloud-init default) | no | Eliminates brute-force and credential stuffing |
| `PermitRootLogin` | yes | no | Least privilege — no direct root access |
| `AllowUsers` | (not set) | admin1 | Restricts SSH to single dedicated admin account |
| `PubkeyAuthentication` | yes | yes | Enforced explicitly — ED25519 key required |
| `MaxAuthTries` | 6 | 3 | Limits consecutive attempts |
| `LoginGraceTime` | 120 | 30 | Closes unauthenticated connections faster |

## Issue encountered

Ubuntu 24.04 ships with `/etc/ssh/sshd_config.d/50-cloud-init.conf` containing
`PasswordAuthentication yes` which silently overrides the main config.
This file was corrected to `PasswordAuthentication no`.

## Key type chosen: ED25519

ED25519 chosen over RSA for:
- Smaller key size with equivalent security
- Faster signature verification
- Resistance to timing side-channel attacks

## Validation procedure

```bash
sudo sshd -t                    # syntax check — must pass before restart
sudo systemctl restart ssh      # apply changes
```

Always keep an existing SSH session open during restart (FM-01).
