# Lab Assumptions

- All VMs run on a single VirtualBox host (Ubuntu 24.04 LTS)
- IPs are statically assigned — no DHCP in lab segments
- strongSwan PSK is used for lab simplicity (not production-grade)
- TLS certificate on srv-web is self-signed (lab only)
- sensor-ids uses promiscuous mode on NH-DMZ for passive capture
- iptables rules must be manually restored after reboot (iptables-persistent not installed)
- IPsec tunnel re-establishes automatically via auto=start
