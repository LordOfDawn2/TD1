#!/bin/bash
# tests/regression/R2_tls.sh
# Claim: srv-web enforces TLS 1.2+, disables weak suites, serves valid cert
# Run from: client (10.10.10.10)
# Date: April 10, 2026

SRV_WEB="10.10.20.10"
PORT=443
TIMEOUT=5
PASS=0
FAIL=0

echo "========================================"
echo " R2 — TLS Hardening Regression Test"
echo " Target: $SRV_WEB:$PORT"
echo " $(date)"
echo "========================================"

check_pass() {
  local desc="$1"; local cmd="$2"
  echo ""
  echo "[TEST] $desc"
  echo "[CMD]  $cmd"
  if eval "$cmd" > /dev/null 2>&1; then
    echo "[PASS] $desc"
    ((PASS++))
  else
    echo "[FAIL] $desc"
    ((FAIL++))
  fi
}

check_fail() {
  local desc="$1"; local cmd="$2"
  echo ""
  echo "[TEST] $desc"
  echo "[CMD]  $cmd"
  if eval "$cmd" > /dev/null 2>&1; then
    echo "[FAIL] $desc — weak config accepted!"
    ((FAIL++))
  else
    echo "[PASS] $desc — correctly rejected"
    ((PASS++))
  fi
}

echo ""
echo "--- TLS VERSION CHECKS ---"

# Check TLS 1.2 is accepted
check_pass "TLS 1.2 accepted" \
  "echo Q | openssl s_client -connect $SRV_WEB:$PORT -tls1_2 -verify_return_error 2>&1 | grep -q 'Cipher'"

# Check TLS 1.3 is accepted
check_pass "TLS 1.3 accepted" \
  "echo Q | openssl s_client -connect $SRV_WEB:$PORT -tls1_3 -verify_return_error 2>&1 | grep -q 'Cipher'"

# Check TLS 1.0 is rejected
check_fail "TLS 1.0 rejected" \
  "echo Q | openssl s_client -connect $SRV_WEB:$PORT -tls1 2>&1 | grep -q 'Cipher'"

# Check TLS 1.1 is rejected
check_fail "TLS 1.1 rejected" \
  "echo Q | openssl s_client -connect $SRV_WEB:$PORT -tls1_1 2>&1 | grep -q 'Cipher'"

echo ""
echo "--- CIPHER SUITE CHECKS ---"

# Check weak RC4 cipher rejected
check_fail "RC4 cipher rejected" \
  "echo Q | openssl s_client -connect $SRV_WEB:$PORT -cipher RC4 2>&1 | grep -q 'Cipher'"

# Check NULL cipher rejected
check_fail "NULL cipher rejected" \
  "echo Q | openssl s_client -connect $SRV_WEB:$PORT -cipher NULL 2>&1 | grep -q 'Cipher'"

echo ""
echo "--- CERTIFICATE CHECK ---"

echo "[TEST] Certificate information"
echo Q | openssl s_client -connect $SRV_WEB:$PORT 2>/dev/null | openssl x509 -noout -subject -issuer -dates 2>/dev/null \
  && echo "[INFO] Certificate details retrieved" \
  || echo "[WARN] Could not retrieve certificate (self-signed or expired)"

echo ""
echo "--- HTTPS CONNECTIVITY ---"
check_pass "HTTPS returns 200 OK" \
  "curl -sk --connect-timeout $TIMEOUT -o /dev/null -w '%{http_code}' https://$SRV_WEB | grep -q 200"

echo ""
echo "========================================"
echo " R2 SUMMARY: $PASS passed, $FAIL failed"
echo "========================================"

[ "$FAIL" -eq 0 ] && exit 0 || exit 1
