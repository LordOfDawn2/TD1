#!/bin/bash
# tests/regression/R1_firewall.sh
# Claim: Firewall policy enforces LAN→DMZ allow-list and blocks all other flows
# Run from: client (10.10.10.10) or any LAN host
# Date: April 10, 2026

SRV_WEB="10.10.20.10"
GW="10.10.10.1"
TIMEOUT=3
PASS=0
FAIL=0

echo "========================================"
echo " R1 — Firewall Policy Regression Test"
echo " Target: $SRV_WEB | GW: $GW"
echo " $(date)"
echo "========================================"

check_pass() {
  local desc="$1"; local cmd="$2"
  echo ""
  echo "[TEST] $desc"
  echo "[CMD]  $cmd"
  if eval "$cmd" > /dev/null 2>&1; then
    echo "[PASS] $desc"
    ((PASS++))
  else
    echo "[FAIL] $desc — expected success, got failure"
    ((FAIL++))
  fi
}

check_fail() {
  local desc="$1"; local cmd="$2"
  echo ""
  echo "[TEST] $desc"
  echo "[CMD]  $cmd"
  if eval "$cmd" > /dev/null 2>&1; then
    echo "[FAIL] $desc — expected block, traffic passed!"
    ((FAIL++))
  else
    echo "[PASS] $desc — correctly blocked"
    ((PASS++))
  fi
}

echo ""
echo "--- POSITIVE TESTS (must succeed) ---"

check_pass "HTTP TCP/80 to srv-web" \
  "curl -s --connect-timeout $TIMEOUT -o /dev/null -w '%{http_code}' http://$SRV_WEB | grep -q 200"

check_pass "SSH TCP/22 to srv-web" \
  "nc -z -w $TIMEOUT $SRV_WEB 22"

check_pass "ICMP echo to srv-web" \
  "ping -c 2 -W $TIMEOUT $SRV_WEB"

check_pass "SSH TCP/22 to gw-fw from LAN" \
  "nc -z -w $TIMEOUT $GW 22"

echo ""
echo "--- NEGATIVE TESTS (must be blocked) ---"

check_fail "Port 12345 to srv-web (not in matrix)" \
  "nc -z -w $TIMEOUT $SRV_WEB 12345"

check_fail "MySQL TCP/3306 to srv-web (not in matrix)" \
  "nc -z -w $TIMEOUT $SRV_WEB 3306"

check_fail "Telnet TCP/23 to srv-web (not in matrix)" \
  "nc -z -w $TIMEOUT $SRV_WEB 23"

check_fail "Port 8080 to srv-web (not in matrix)" \
  "nc -z -w $TIMEOUT $SRV_WEB 8080"

check_fail "DNS UDP/53 to srv-web (not in matrix)" \
  "nc -u -z -w $TIMEOUT $SRV_WEB 53"

check_fail "Port 9999 to srv-web (not in matrix)" \
  "nc -z -w $TIMEOUT $SRV_WEB 9999"

echo ""
echo "========================================"
echo " R1 SUMMARY: $PASS passed, $FAIL failed"
echo "========================================"

[ "$FAIL" -eq 0 ] && exit 0 || exit 1
