#!/bin/bash
# tests/regression/R4_detection.sh
# Claim: IDS (sensor-ids) detects and logs suspicious flows on NH-DMZ
# Generates a known test flow and checks for alert/log evidence
# Run from: client (10.10.10.10)
# Date: April 10, 2026

SRV_WEB="10.10.20.10"
SENSOR="10.10.20.50"
TIMEOUT=3
PASS=0
FAIL=0

echo "========================================"
echo " R4 — IDS Detection Regression Test"
echo " Target: $SRV_WEB | Sensor: $SENSOR"
echo " $(date)"
echo "========================================"

echo ""
echo "--- GENERATING TEST FLOWS ---"

echo "[TEST] Port scan simulation (nmap SYN scan to srv-web)"
echo "[CMD]  nmap -sS -p 1-1024 --open $SRV_WEB (simulated)"
# We generate blocked flows that IDS should see
for port in 3306 23 8080 12345 9999; do
  nc -z -w 1 $SRV_WEB $port 2>/dev/null || true
done
echo "[INFO] Blocked flows sent to $SRV_WEB on ports: 3306 23 8080 12345 9999"

echo ""
echo "[TEST] HTTP request with suspicious user-agent (SQLi probe)"
echo "[CMD]  curl -sA 'sqlmap/1.0' http://$SRV_WEB/"
curl -s --connect-timeout $TIMEOUT -A "sqlmap/1.0-dev" \
  "http://$SRV_WEB/" -o /dev/null 2>/dev/null || true
echo "[INFO] SQLi-like user-agent request sent"

echo ""
echo "[TEST] HTTP request with directory traversal attempt"
curl -s --connect-timeout $TIMEOUT \
  "http://$SRV_WEB/../../../etc/passwd" -o /dev/null 2>/dev/null || true
echo "[INFO] Directory traversal probe sent"

echo ""
echo "--- CHECKING FOR IDS ALERTS ---"

echo "[TEST] Suricata/IDS logs on sensor-ids"
echo "[CMD]  ssh user@$SENSOR 'sudo tail -20 /var/log/suricata/fast.log 2>/dev/null'"
echo "[INFO] To verify manually on sensor-ids:"
echo "       sudo tail -50 /var/log/suricata/fast.log | grep -E 'ET SCAN|ATTACK|POLICY'"
echo "       sudo tail -50 /var/log/suricata/eve.json | python3 -m json.tool | head -80"

# Check if sensor is reachable
if nc -z -w $TIMEOUT $SENSOR 22 2>/dev/null; then
  echo "[PASS] sensor-ids (10.10.20.50) is reachable via SSH"
  ((PASS++))
  echo "[INFO] Connect to sensor-ids to verify alerts:"
  echo "       ssh user@$SENSOR 'sudo tail -20 /var/log/suricata/fast.log'"
else
  echo "[WARN] sensor-ids not reachable via SSH — check VM state"
  ((FAIL++))
fi

echo ""
echo "--- FIREWALL LOG CHECK (deny evidence) ---"
echo "[INFO] IPT_FWD_DENY entries should exist after blocked flows above."
echo "[INFO] Run on gw-fw: sudo journalctl -k --since '5 minutes ago' | grep IPT_FWD_DENY"

echo ""
echo "--- SENSOR PLACEMENT VERIFICATION ---"
echo "[TEST] sensor-ids responds on NH-DMZ"
if ping -c 2 -W $TIMEOUT $SENSOR > /dev/null 2>&1; then
  echo "[PASS] sensor-ids reachable on NH-DMZ (10.10.20.50)"
  ((PASS++))
else
  echo "[WARN] sensor-ids not responding to ping — check VM and interface"
fi

echo ""
echo "========================================"
echo " R4 SUMMARY: $PASS passed, $FAIL failed"
echo "[NOTE] IDS alert verification requires manual check on sensor-ids"
echo "========================================"

[ "$FAIL" -eq 0 ] && exit 0 || exit 1
