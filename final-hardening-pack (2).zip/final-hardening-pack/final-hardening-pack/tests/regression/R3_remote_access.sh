#!/bin/bash
# tests/regression/R3_remote_access.sh
# Claim: SSH to siteB-srv uses key-only auth; root login disabled;
#        password auth disabled; only admin1 allowed
# Run from: siteA-client (10.10.10.10)
# Date: April 10, 2026

SRV="10.10.20.10"
KEY="$HOME/.ssh/id_td5"
ADMIN="admin1"
TIMEOUT=5
PASS=0
FAIL=0

echo "========================================"
echo " R3 — Remote Access Regression Test"
echo " Target: $SRV | User: $ADMIN"
echo " $(date)"
echo "========================================"

check_pass() {
  local desc="$1"; local cmd="$2"
  echo ""
  echo "[TEST] $desc"
  echo "[CMD]  $cmd"
  if eval "$cmd" > /dev/null 2>&1; then
    echo "[PASS] $desc"
    ((PASS++))
  else
    echo "[FAIL] $desc — expected success"
    ((FAIL++))
  fi
}

check_fail() {
  local desc="$1"; local cmd="$2"
  echo ""
  echo "[TEST] $desc"
  echo "[CMD]  $cmd"
  if eval "$cmd" > /dev/null 2>&1; then
    echo "[FAIL] $desc — expected block!"
    ((FAIL++))
  else
    echo "[PASS] $desc — correctly blocked"
    ((PASS++))
  fi
}

echo ""
echo "--- SSH POSITIVE TESTS ---"

check_pass "Key-based SSH as admin1 works" \
  "ssh -i $KEY -o ConnectTimeout=$TIMEOUT -o StrictHostKeyChecking=no \
   -o BatchMode=yes $ADMIN@$SRV 'echo SSH_KEY_OK' | grep -q SSH_KEY_OK"

check_pass "SSH reaches siteB-srv (port open)" \
  "nc -z -w $TIMEOUT $SRV 22"

echo ""
echo "--- SSH NEGATIVE TESTS ---"

check_fail "Password auth rejected for admin1" \
  "ssh -o ConnectTimeout=$TIMEOUT -o StrictHostKeyChecking=no \
   -o BatchMode=yes -o PubkeyAuthentication=no \
   $ADMIN@$SRV 'echo SHOULD_NOT_WORK' 2>&1 | grep -q SHOULD_NOT_WORK"

check_fail "Root login rejected" \
  "ssh -i $KEY -o ConnectTimeout=$TIMEOUT -o StrictHostKeyChecking=no \
   -o BatchMode=yes root@$SRV 'echo SHOULD_NOT_WORK' 2>&1 | grep -q SHOULD_NOT_WORK"

check_fail "Other user rejected (AllowUsers)" \
  "ssh -i $KEY -o ConnectTimeout=$TIMEOUT -o StrictHostKeyChecking=no \
   -o BatchMode=yes user@$SRV 'echo SHOULD_NOT_WORK' 2>&1 | grep -q SHOULD_NOT_WORK"

echo ""
echo "--- IPSEC VPN CHECK ---"

echo "[TEST] IPsec tunnel status"
if sudo ipsec statusall 2>/dev/null | grep -q "ESTABLISHED"; then
  echo "[PASS] IPsec tunnel ESTABLISHED"
  ((PASS++))
else
  echo "[WARN] IPsec tunnel not ESTABLISHED — check strongSwan"
  echo "       Run: sudo systemctl restart strongswan-starter"
fi

echo "[TEST] ESP traffic visible on WAN (passive check)"
if sudo ipsec statusall 2>/dev/null | grep -q "INSTALLED, TUNNEL"; then
  echo "[PASS] CHILD_SA INSTALLED — tunnel carrying traffic"
  ((PASS++))
else
  echo "[WARN] CHILD_SA not INSTALLED"
fi

echo ""
echo "--- AUTH LOG AUDIT ---"
echo "[INFO] Recent SSH accepts/denies on siteB-srv:"
echo "       (run 'sudo tail -20 /var/log/auth.log' on srv-web for full audit)"

echo ""
echo "========================================"
echo " R3 SUMMARY: $PASS passed, $FAIL failed"
echo "========================================"

[ "$FAIL" -eq 0 ] && exit 0 || exit 1
