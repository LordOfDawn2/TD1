#!/bin/bash
# tests/regression/run_all.sh
# Master regression suite — Network Hardening TD6
# Runs all regression scripts and stores results with timestamp
# Exit code: 0 if all pass, 1 if any critical test fails

set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
TIMESTAMP=$(date +"%Y%m%d_%H%M%S")
RESULTS_DIR="$SCRIPT_DIR/results/$TIMESTAMP"
mkdir -p "$RESULTS_DIR"

PASS=0
FAIL=0
CRITICAL_FAIL=0

echo "=============================================="
echo " Network Hardening — Regression Suite"
echo " $(date)"
echo " Results: $RESULTS_DIR"
echo "=============================================="

run_script() {
  local script="$1"
  local name="$2"
  local critical="${3:-false}"
  local outfile="$RESULTS_DIR/$(basename "$script" .sh).txt"

  echo ""
  echo "--- Running: $name ---"
  if bash "$SCRIPT_DIR/$script" 2>&1 | tee "$outfile"; then
    echo "[PASS] $name"
    ((PASS++))
  else
    echo "[FAIL] $name"
    ((FAIL++))
    if [ "$critical" = "true" ]; then
      ((CRITICAL_FAIL++))
    fi
  fi
}

run_script "R1_firewall.sh"      "R1 — Firewall policy"      "true"
run_script "R2_tls.sh"           "R2 — TLS hardening"        "false"
run_script "R3_remote_access.sh" "R3 — Remote access (SSH+VPN)" "true"
run_script "R4_detection.sh"     "R4 — IDS detection"        "false"

echo ""
echo "=============================================="
echo " RESULTS: $PASS passed, $FAIL failed"
echo " Results saved to: $RESULTS_DIR"
echo "=============================================="

if [ "$CRITICAL_FAIL" -gt 0 ]; then
  echo " [CRITICAL] $CRITICAL_FAIL critical test(s) failed — review immediately"
  exit 1
fi

exit 0
