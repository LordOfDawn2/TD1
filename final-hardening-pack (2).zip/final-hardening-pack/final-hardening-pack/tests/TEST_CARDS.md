# TEST_CARDS.md — TD2 Firewall Policy

---

## TD2-T01 — Allowed flows from matrix pass (HTTP)

**Claim:** HTTP (TCP/80) from LAN to srv-web is forwarded by gw-fw.

**Positive test:**
```bash
curl -sI http://10.10.20.10 | head -5
# Expected: HTTP/1.1 200 OK
```

**Negative test:** N/A (covered by T02)

**Evidence:** `evidence/counters_after.txt`, `tests/commands.txt`

---

## TD2-T02 — Default deny blocks unlisted traffic

**Claim:** Traffic to ports not in the allow-list is dropped by the FORWARD chain.

**Positive test:** N/A

**Negative test:**
```bash
nc -vz -w 3 10.10.20.10 12345
# Expected: connection timeout (not refused — DROP policy)
```

**Evidence:** `evidence/deny_logs.txt`

---

## TD2-T03 — Denied traffic produces telemetry

**Claim:** Blocked forwarded packets generate log entries on gw-fw with prefix `IPT_FWD_DENY`.

**Positive test:**
```bash
# After running negative tests, on gw-fw:
sudo journalctl -k --since "10 minutes ago" | grep "IPT_FWD_DENY"
# Expected: log entries with SRC/DST/PROTO/DPT fields
```

**Negative test:** Without negative test traffic, no `IPT_FWD_DENY` entries appear.

**Evidence:** `evidence/deny_logs.txt`

---

## TD2-T04 — Ruleset is reversible

**Claim:** `rollback.sh` restores a permissive state within 30 seconds.

**Positive test:**
```bash
# From VirtualBox console on gw-fw:
bash ~/TD2/config/rollback.sh
# Expected: all policies set to ACCEPT, all traffic permitted
sudo iptables -L | grep "policy ACCEPT"
```

**Negative test:** N/A

**Evidence:** `config/rollback.sh`

---

## TD2-T05 — Admin SSH access preserved at all times

**Claim:** SSH from LAN to gw-fw (INPUT chain) works at all times, including after default deny.

**Positive test:**
```bash
ssh -o ConnectTimeout=3 user@10.10.10.1 whoami
# Expected: user
```

**Negative test:**
```bash
# SSH from DMZ to gw-fw (not in allow-list)
nc -vz -w 3 10.10.20.1 22
# Expected: timeout (INPUT DROP from DMZ)
```

**Evidence:** `tests/commands.txt`

---

## TD2-T06 — Rules are minimal and scoped (no any-any)

**Claim:** Each rule in the ruleset specifies explicit source, destination, and port. No wildcard rule exists.

**Positive test:**
```bash
cat config/firewall_ruleset.txt | grep -v "^#" | grep -v "^$"
# Expected: all FORWARD ACCEPT rules have -s, -d, and --dport
```

**Negative test:** No rule matches `0.0.0.0/0` as source or destination in ACCEPT rules.

**Evidence:** `config/firewall_ruleset.txt`

---

## TD2-T07 — Counter analysis shows enforcement

**Claim:** The deny rule counter increments after negative tests, proving traffic is intercepted.

**Positive test:**
```bash
# Compare counters before and after negative tests:
diff evidence/counters_before.txt evidence/counters_after.txt
# Expected: packet/byte counters higher in counters_after.txt for LOG/DROP rules
```

**Negative test:** If counters don't increment, traffic is not reaching gw-fw (routing issue).

**Evidence:** `evidence/counters_before.txt`, `evidence/counters_after.txt`
-e 
---

# TEST_CARDS.md — TD5 Test Plan

---

## TD5-T01 — SSH password authentication disabled

**Claim:** Password-based SSH login is rejected on siteB-srv.

**Positive test:**
```bash
ssh -i ~/.ssh/id_td5 admin1@10.10.20.10 "echo SSH_KEY_OK"
# Expected: SSH_KEY_OK
```

**Negative test:**
```bash
ssh -o PubkeyAuthentication=no admin1@10.10.20.10
# Expected: Permission denied (publickey).
```

**Evidence:** `evidence/ssh_tests.txt`, `evidence/authlog_excerpt.txt`

---

## TD5-T02 — Root login via SSH disabled

**Claim:** Direct SSH login as root is blocked by `PermitRootLogin no`.

**Positive test:** N/A

**Negative test:**
```bash
ssh -i ~/.ssh/id_td5 root@10.10.20.10
# Expected: Permission denied (publickey).
```

**Evidence:** `evidence/ssh_tests.txt`

---

## TD5-T03 — AllowUsers restricts SSH to admin1 only

**Claim:** `AllowUsers admin1` prevents any other user from connecting.

**Positive test:**
```bash
ssh -i ~/.ssh/id_td5 admin1@10.10.20.10
# Expected: connection established
```

**Negative test:**
```bash
ssh -i ~/.ssh/id_td5 user@10.10.20.10
# Expected: Permission denied — not listed in AllowUsers
```

**Evidence:** `evidence/authlog_excerpt.txt`

---

## TD5-T04 — SSH audit trail in auth.log

**Claim:** `/var/log/auth.log` records accepts and denies with username, method, and source IP.

**Positive test:**
```bash
sudo tail -n 50 /var/log/auth.log | grep "Accepted publickey"
# Expected: Accepted publickey for admin1 from 10.10.10.10
```

**Negative test:**
```bash
sudo tail -n 50 /var/log/auth.log | grep "not allowed"
# Expected: User root from 10.10.10.10 not allowed because not listed in AllowUsers
```

**Evidence:** `evidence/authlog_excerpt.txt`

---

## TD5-T05 — IKEv2 tunnel establishes successfully

**Claim:** `ipsec statusall` shows IKE_SA ESTABLISHED and CHILD_SA INSTALLED on both gateways.

**Positive test:**
```bash
# On both gateways
sudo ipsec statusall | grep -E "ESTABLISHED|INSTALLED"
# Expected: ESTABLISHED + INSTALLED, TUNNEL
```

**Negative test:** Block UDP 500 on siteA-gw → tunnel fails to negotiate (no IKE exchange).

**Evidence:** `evidence/ipsec_status.txt`

---

## TD5-T06 — Traffic passes through IPsec tunnel

**Claim:** Ping from siteA-client to siteB-srv traverses the IPsec tunnel (4/4 packets, 0% loss).

**Positive test:**
```bash
# From siteA-client
ping -c 4 10.10.20.10
# Expected: 4 packets transmitted, 4 received, 0% packet loss
```

**Negative test:** Without active tunnel → ping timeout (no alternative route).

**Evidence:** `evidence/tunnel_ping.txt`

---

## TD5-T07 — Traffic is encrypted (ESP visible, no cleartext)

**Claim:** The WAN segment reveals only ESP packets — no cleartext ICMP.

**Positive test:**
```bash
# On siteA-gw during ping from siteA-client
sudo tcpdump -i enp0s8 -c 20 'udp port 500 or udp port 4500 or esp'
# Expected: only ESP packets — no ICMP in cleartext
```

**Negative test:** If tunnel is down → cleartext ICMP visible on WAN.

**Evidence:** `evidence/tunnel_ping.txt` (tcpdump section)

---

## TD5-T08 — Tunnel scoped to LAN <-> DMZ only

**Claim:** IPsec config limits traffic to 10.10.10.0/24 <-> 10.10.20.0/24. No 0.0.0.0/0 tunnelling.

**Positive test:**
```bash
grep -E "leftsubnet|rightsubnet" /etc/ipsec.conf
# Expected:
# leftsubnet=10.10.10.0/24
# rightsubnet=10.10.20.0/24
```

**Negative test:** Traffic to addresses outside these subnets is NOT tunnelled (routes not covered by SPD).

**Evidence:** `config/ipsec_siteA.conf`, `config/ipsec_siteB.conf`
