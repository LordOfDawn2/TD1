# Executive Summary — Network Hardening Project
## ESILV Year 4 | April 2026 | One-page brief

---

## Top 3 Business Risks (Before Hardening)

1. **Unrestricted lateral movement** — any compromised host on the LAN could directly reach all DMZ services on any port, with no traffic inspection or logging. A single phishing email could lead to full DMZ compromise.

2. **Cleartext administrative traffic** — SSH passwords and inter-site management traffic were transmitted in cleartext over the WAN segment, exposing credentials to any passive observer on the network.

3. **No visibility on threats** — without an IDS, malicious activity (port scans, SQLi probes, brute-force) would go completely undetected. There was no audit trail for forensic purposes.

---

## 5 Controls Implemented

| # | Control | What it does |
|---|---|---|
| 1 | **Firewall policy (iptables)** | Default-deny between LAN and DMZ; only HTTP, HTTPS, SSH, and ICMP are permitted; all blocks are logged |
| 2 | **SSH hardening** | Key-only authentication (ED25519); root login disabled; only dedicated admin account allowed; grace time and retry limits set |
| 3 | **IPsec IKEv2 VPN** | All cross-site traffic encrypted with AES-256/SHA-256; tunnel scoped to intended subnets only; no cleartext on WAN |
| 4 | **TLS hardening** | TLS 1.2 minimum enforced; TLS 1.0/1.1 rejected; weak cipher suites disabled on the web service |
| 5 | **IDS deployment** | Suricata sensor placed on DMZ segment in promiscuous mode; tuned rules detect port scans, known attack patterns, and policy violations |

---

## Residual Risk

The following items remain **unresolved** and represent accepted risk for this lab phase:

- VPN uses PSK (no certificate revocation capability) — production would require PKI
- No multi-factor authentication on SSH — a stolen key provides full access
- DMZ-to-LAN traffic not restricted — lateral movement between DMZ hosts is possible
- Logs are not centralised — forensic investigation requires manual access to each VM
- TLS certificate is self-signed — no browser trust without a CA

---

## Next Actions (30 / 60 / 90 Days)

**30 days — Quick wins**
- Install `iptables-persistent` for rule persistence across reboots
- Rotate SSH keys and enforce key expiry policy
- Forward logs (auth.log, syslog) to a centralised SIEM
- Replace PSK with X.509 certificates for IPsec

**60 days — Architecture improvements**
- Add DMZ→LAN egress control rules (restrict lateral movement)
- Deploy WAF in front of srv-web for application-layer protection
- Add TOTP/FIDO2 as second factor for SSH access
- Configure TLS with a trusted CA (Let's Encrypt or internal PKI)

**90 days — Governance and automation**
- Automate regression suite in CI/CD pipeline (run on every config change)
- Implement Infrastructure-as-Code for firewall rules (Ansible/Terraform)
- Establish quarterly policy review cadence
- Document incident response procedure for firewall lockout and VPN failure
