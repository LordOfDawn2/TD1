# TD4 — TLS Audit and Hardening: Evidence Pack

**Module:** Network Hardening — ESILV 4th year
**Date:** 2026-04-10
**Normative anchor:** NIST SP 800-52 Rev.2 + RFC 8446

---

## 1. Threat Model

**Asset:** Web service on srv-web (10.10.20.10), port 8443 (TLS) and 8080 (HTTP test endpoint).

**Adversary:** On-path attacker on the NH-LAN or NH-DMZ segment, or a remote scanner targeting the service from the client VM (10.10.10.10).

**Key threats:**
- Downgrade attack to weak protocol version (TLS 1.0 / TLS 1.1)
- Negotiation of weak cipher suite lacking forward secrecy (CBC-based, RSA key exchange)
- Broken or expired certificate chain causing users to bypass warnings
- Misconfigured edge allowing information leakage via headers or error pages
- Denial of service via unrestricted request flooding
- Automated scanning tools (sqlmap, nikto) probing for vulnerabilities

**Security goals:**
- Only modern TLS versions are offered (TLS 1.2 and TLS 1.3)
- Cipher policy enforces forward secrecy (ECDHE key exchange only)
- Certificate chain is valid for the lab trust model (self-signed, documented)
- Edge controls provide basic availability protection and request filtering

---

## 2. TLS Profile

| Parameter | Decision | NIST SP 800-52r2 ref |
|---|---|---|
| Minimum TLS version | TLS 1.2 | §3.1 — servers SHALL support TLS 1.2 |
| Maximum TLS version | TLS 1.3 enabled | §3.1 — SHOULD support TLS 1.3 |
| Cipher strategy | AEAD only: ECDHE+AESGCM + ECDHE+CHACHA20 | §3.3 — prefer AEAD cipher suites |
| Disabled ciphers | No CBC, no RC4, no MD5, no aNULL | §3.3 — SHALL NOT use RC4 or NULL |
| Forward secrecy | Required — all suites use ECDHE | §3.3 |
| Server cipher preference | on (ssl_prefer_server_ciphers) | §3.3 |
| Certificate | Self-signed RSA 2048, CN=td4.local | Lab trust model, documented |
| HSTS | max-age=300 (short for lab) | §3.5 — SHOULD enable HSTS |

---

## 3. Baseline Audit ("Before")

### 3.1 Scanner: nmap ssl-enum-ciphers

Command:
```
nmap --script ssl-enum-ciphers -p 8443 10.10.20.10
```

Evidence file: `evidence/before/nmap_ciphers.txt`

Key findings:
- TLSv1.2 only (TLS 1.3 not offered)
- 26 cipher suites offered including CBC and non-FS (RSA key exchange) suites
- cipher preference: **client** (server does not enforce strongest)
- least strength: A (misleading — CBC suites present)

### 3.2 Scanner: openssl s_client

Command:
```
openssl s_client -connect 10.10.20.10:8443 -servername td4.local </dev/null
```

Evidence file: `evidence/before/openssl_s_client.txt`

Key findings:
- Certificate: CN=td4.local, self-signed (verify error num=18)
- PKEY: RSA 2048, sigalg: sha256WithRSAEncryption
- Validity: Apr 10 00:22:58 2026 GMT → Apr 17 00:22:58 2026 GMT

### 3.3 Scanner: curl -vk

Command:
```
curl -vk https://10.10.20.10:8443/ 2>&1
```

Evidence file: `evidence/before/curl_vk.txt`

Key findings:
- SSL connection using TLSv1.2 / ECDHE-RSA-AES256-GCM-SHA384
- No Strict-Transport-Security header

### 3.4 Before Profile Table

| Item | Finding | Evidence file |
|---|---|---|
| Protocol versions offered | TLSv1.2 (TLS 1.0/1.1 in config) | nmap_ciphers.txt |
| Cipher families | CBC + AEAD mixed (26 suites) | nmap_ciphers.txt |
| Non-FS ciphers | Yes — TLS_RSA_WITH_* suites | nmap_ciphers.txt |
| Forward secrecy | Partial | nmap_ciphers.txt |
| Cipher preference | Client | nmap_ciphers.txt |
| Certificate subject | CN=td4.local | openssl_s_client.txt |
| Certificate validity | 7 days (Apr 10–17 2026) | openssl_s_client.txt |
| Key size / algorithm | RSA 2048, sha256WithRSAEncryption | openssl_s_client.txt |
| Chain status | Self-signed | openssl_s_client.txt |
| HSTS | Not present | curl_vk.txt |
| Obvious risk | Mixed cipher policy — CBC + non-FS suites; client chooses cipher | nmap_ciphers.txt |

---

## 4. TLS Hardening

### 4.1 Changes Applied

| Change | Before | After | NIST SP 800-52r2 ref |
|---|---|---|---|
| ssl_protocols | TLSv1 TLSv1.1 TLSv1.2 | TLSv1.2 TLSv1.3 | §3.1 — SHALL NOT support TLS 1.0/1.1 |
| ssl_ciphers | HIGH:MEDIUM:!aNULL | ECDHE+AESGCM:ECDHE+CHACHA20:!aNULL:!MD5:!RC4 | §3.3 — prefer AEAD cipher suites |
| ssl_prefer_server_ciphers | off (default) | on | §3.3 — server controls cipher selection |
| HSTS header | absent | max-age=300 | §3.5 — SHOULD enable HSTS |
| User-agent filter | absent | sqlmap\|nikto → 403 | Edge hardening |
| Rate limiting | absent | 1r/s, burst=2 on /api | Availability protection |

See `config/change_log.md` for full line-by-line documentation.

---

## 5. After Audit — Before / After Comparison

| Item | Before | After | Evidence file |
|---|---|---|---|
| TLS 1.0 | Configured | Not offered | nmap after |
| TLS 1.1 | Configured | Not offered | nmap after |
| TLS 1.2 | Offered | Offered | nmap before/after |
| TLS 1.3 | Not offered | **Offered** | nmap after + curl after |
| CBC ciphers | 26 suites (CBC+AEAD) | **Removed** | nmap after |
| Non-FS ciphers (RSA) | Present | **Removed** | nmap after |
| Cipher count | 26 suites | **6 suites** | nmap after |
| Cipher preference | Client | **Server** | nmap after |
| Forward secrecy | Partial | **All suites (ECDHE)** | nmap after |
| HSTS | Absent | **max-age=300** | curl after |
| Negotiated cipher | TLSv1.2 / ECDHE-RSA-AES256-GCM-SHA384 | **TLSv1.3 / TLS_AES_256_GCM_SHA384** | curl after |
| Cert subject | CN=td4.local | CN=td4.local (lab) | openssl after |

---

## 6. Edge Controls

### Control 1 — Rate Limiting

Config (nginx http block):
```nginx
limit_req_zone $binary_remote_addr zone=api:10m rate=1r/s;
```

Config (location block):
```nginx
location /api {
    limit_req zone=api burst=2;
    return 200 "API ok\n";
}
```

Proof: nginx access log shows requests from 10.10.10.10 hitting /api endpoint.
Evidence file: `evidence/after/nginx_access_log.txt`

### Control 2 — Request Filtering (User-Agent)

Config:
```nginx
if ($http_user_agent ~* "sqlmap|nikto") { return 403; }
```

Proof:
- Clean request: `curl -sk https://10.10.20.10:8443/` → `TLS hardened` (200)
- Malicious UA: `curl -sk -A "sqlmap/1.0" https://10.10.20.10:8443/` → `403 Forbidden`

Evidence file: `evidence/after/filter_test.txt`

---

## 7. Log Triage

### 7.1 What happened?

During the edge control test phase, the client VM (10.10.10.10) sent a series of requests to nginx on srv-web. A request with user-agent string `sqlmap/1.0` was sent to simulate an automated scanner. nginx immediately returned 403 Forbidden, confirming the user-agent filter is active and blocks the request before any content is processed.

### 7.2 Signal

| Field | Value |
|---|---|
| Source IP | 10.10.10.10 |
| Timestamp | 10/Apr/2026 ~01:30 UTC+0 |
| Path | / |
| Status code | 403 |
| User-agent | sqlmap/1.0 |
| Trigger | $http_user_agent ~* "sqlmap\|nikto" |

### 7.3 Classification

**Simulated scan / automated tool** — controlled lab test. In production: likely reconnaissance scan from automated vulnerability scanner.

### 7.4 Next Steps in a Real SOC

- Enrich source IP against threat intel feeds — is it a known scanner or unexpected subnet?
- Correlate with IDS alerts on sensor-ids (10.10.20.50) — check for TLS handshake anomalies or port scan patterns
- Check for other requests from same IP in same time window — multiple 403s = active scan campaign
- If confirmed malicious: add IP to firewall blocklist on gw-fw and open incident ticket

---

## 8. Residual Risks

| Risk | Mitigation |
|---|---|
| Certificate expires in 7 days | Production: Let's Encrypt + auto-renewal or internal CA |
| Self-signed cert — no chain trust | Lab only. Production: cert signed by trusted CA |
| User-agent filter bypassable | Complement with IP rate limiting or full WAF (ModSecurity + OWASP CRS) |
| Rate limit tuning | Tune burst based on real traffic baseline to avoid false positives |
| No upstream authentication | Production requires auth layer (OAuth2, mTLS, API keys) |
| HTTP port 8080 open | Opened for rate limit testing — remove in production |
