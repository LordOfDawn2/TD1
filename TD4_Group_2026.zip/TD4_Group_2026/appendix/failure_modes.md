# Failure Modes — TD4

| ID | Failure | Symptom | Fix |
|---|---|---|---|
| FM-01 | nginx reload fails | `nginx -t` shows syntax error | Fix config before reloading. Always run `nginx -t` first. |
| FM-02 | /opt/tls owned by root | Permission denied on cert files | Use `sudo` for all operations in /opt/tls |
| FM-03 | Docker not installed | `docker: command not found` | Used native nginx instead — functionally equivalent for the lab |
| FM-04 | Typo in directive | `unknown directive 'ssl_prefer_server_cipher'` | Correct spelling: `ssl_prefer_server_ciphers` (with trailing s) |
| FM-05 | Rate limit not triggering | All requests return 200 | Sequential curl is too slow for r/s threshold — TLS handshake overhead spaces requests. Use parallel tool (ab, hey) or lower rate to r/m for demo |
| FM-06 | Port 8080 connection refused | `curl` returns 000 | Run: `sudo iptables -I INPUT -p tcp --dport 8080 -j ACCEPT` |
| FM-07 | https on port 8080 | 000 / SSL error | Port 8080 is plain HTTP — use `http://` not `https://` |
| FM-08 | openssl certs/srv/key path error | `Can't open certs/srv/key for writing` | Space in `-keyout certs/srv.key` interpreted as path — use full path `/opt/tls/certs/key.pem` |
| FM-09 | Second server block rejected | `server directive not allowed here` | Missing closing `}` for first server block before second server block |
