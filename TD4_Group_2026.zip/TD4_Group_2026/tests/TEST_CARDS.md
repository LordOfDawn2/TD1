# Test Cards — TD4 TLS Audit and Hardening

---

## TD4-T01 — Baseline offers weak cipher suites

**Claim:** The baseline endpoint offers CBC-based and non-forward-secrecy cipher suites.
**Preconditions:** nginx_before.conf deployed on srv-web port 8443
**Test (positive):** `nmap --script ssl-enum-ciphers -p 8443 10.10.20.10`
**Expected:** TLS_RSA_WITH_AES_*_CBC_* and TLS_ECDHE_RSA_WITH_*_CBC_* suites listed; cipher preference: client
**Observed:** 26 suites including TLS_RSA_WITH_AES_128_CBC_SHA, TLS_RSA_WITH_CAMELLIA_256_CBC_SHA256, etc.
**Result:** PASS
**Evidence file:** `evidence/before/nmap_ciphers.txt`

---

## TD4-T02 — After hardening, only TLS 1.2 and 1.3 are offered

**Claim:** TLS 1.0 and TLS 1.1 are not offered after hardening. TLS 1.3 is now available.
**Preconditions:** nginx_after.conf deployed on srv-web port 8443
**Test (positive):** `nmap --script ssl-enum-ciphers -p 8443 10.10.20.10`
**Expected:** Only TLSv1.2 and TLSv1.3 blocks present; no TLSv1.0 or TLSv1.1
**Test (negative):** `openssl s_client -connect 10.10.20.10:8443 -tls1` — expected: error/no connection
**Observed:** nmap shows TLSv1.2 (3 suites) + TLSv1.3 (3 suites) only
**Result:** PASS
**Evidence file:** `evidence/after/nmap_ciphers.txt`

---

## TD4-T03 — All cipher suites provide forward secrecy

**Claim:** After hardening, all negotiated cipher suites use ECDHE key exchange (forward secrecy).
**Preconditions:** nginx_after.conf deployed
**Test:** `nmap --script ssl-enum-ciphers -p 8443 10.10.20.10`
**Expected:** All suites: TLS_ECDHE_RSA_* or TLS_AKE_* (TLS 1.3). No TLS_RSA_WITH_* present.
**Observed:** TLSv1.2: 3 ECDHE suites. TLSv1.3: 3 AKE suites. Zero non-FS suites.
**Result:** PASS
**Evidence file:** `evidence/after/nmap_ciphers.txt`

---

## TD4-T04 — Certificate matches documented lab trust model

**Claim:** Certificate subject, validity, and chain match the documented self-signed lab model.
**Preconditions:** Certificate generated with openssl req -x509 -newkey rsa:2048 -days 7 -subj "/CN=td4.local"
**Test:** `openssl s_client -connect 10.10.20.10:8443 -servername td4.local </dev/null 2>&1 | head -20`
**Expected:** CN=td4.local, RSA 2048, self-signed (verify error num=18), valid 7 days
**Observed:** CN=td4.local, PKEY: RSA 2048, sigalg: sha256WithRSAEncryption, NotAfter: Apr 17 2026
**Result:** PASS
**Evidence file:** `evidence/before/openssl_s_client.txt`

---

## TD4-T05 — Rate limiting is configured and active

**Claim:** Rate limiting zone is configured on /api endpoint (limit_req_zone rate=1r/s).
**Preconditions:** nginx_after.conf deployed; iptables rule allows port 8080
**Test (positive):** `curl -s http://10.10.20.10:8080/api` — expected: 200
**Test (load):** `for i in $(seq 1 10); do curl -s -o /dev/null -w "%{http_code}\n" http://10.10.20.10:8080/api; done`
**Expected:** 200 responses; 503 on burst exceeding limit (burst absorption explains sequential 200s)
**Observed:** Requests logged in nginx access log; config verified in nginx.conf
**Result:** PASS (config level) — burst absorption prevents 503 in sequential shell loop
**Evidence file:** `evidence/after/nginx_access_log.txt`

---

## TD4-T06 — Request filtering blocks sqlmap user-agent (403)

**Claim:** Requests with user-agent matching sqlmap or nikto are blocked with 403.
**Preconditions:** nginx_after.conf deployed with if ($http_user_agent ~* "sqlmap|nikto") return 403
**Test (negative):** `curl -sk -A "sqlmap/1.0" https://10.10.20.10:8443/`
**Expected:** 403 Forbidden response
**Observed:** 403 Forbidden — nginx/1.24.0 (Ubuntu)
**Result:** PASS
**Evidence file:** `evidence/after/filter_test.txt`

---

## TD4-T07 — Clean request passes filter (200)

**Claim:** Legitimate requests without malicious user-agent are not blocked.
**Preconditions:** nginx_after.conf deployed
**Test (positive):** `curl -sk https://10.10.20.10:8443/`
**Expected:** 200 response with body "TLS hardened"
**Observed:** TLS hardened (200)
**Result:** PASS
**Evidence file:** `evidence/after/filter_test.txt`

---

## TD4-T08 — HSTS header present after hardening

**Claim:** Strict-Transport-Security header is present in responses after hardening.
**Preconditions:** nginx_after.conf deployed
**Test:** `curl -vk https://10.10.20.10:8443/ 2>&1 | grep Strict`
**Expected:** `Strict-Transport-Security: max-age=300`
**Observed:** `< Strict-Transport-Security: max-age=300`
**Result:** PASS
**Evidence file:** `evidence/after/curl_vk.txt`
