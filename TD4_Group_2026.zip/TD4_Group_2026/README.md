# TD4 — TLS Audit and Hardening

**Module:** Network Hardening (4th-year engineering — ESILV)
**Date:** 2026-04-10
**Normative anchor:** NIST SP 800-52 Rev.2 + RFC 8446

---

## Environment

| VM | Role | IP |
|---|---|---|
| gw-fw | Firewall | 10.10.10.1 / 10.10.20.1 |
| client | Scanner / tester (Kali) | 10.10.10.10 |
| srv-web | TLS endpoint (nginx native) | 10.10.20.10 |
| sensor-ids | IDS (optional) | 10.10.20.50 |

TLS endpoint: `https://10.10.20.10:8443/`

---

## How to Reproduce

### 1. Generate certificate (on srv-web)
```bash
mkdir -p /opt/tls/certs
sudo openssl req -x509 -newkey rsa:2048 \
  -keyout /opt/tls/certs/key.pem \
  -out /opt/tls/certs/crt.pem \
  -days 7 -nodes -subj "/CN=td4.local"
```

### 2. Deploy baseline config
```bash
sudo cp config/nginx_before.conf /etc/nginx/nginx.conf
sudo nginx -t && sudo systemctl reload nginx
```

### 3. Run before scans (from client)
```bash
nmap --script ssl-enum-ciphers -p 8443 10.10.20.10
openssl s_client -connect 10.10.20.10:8443 -servername td4.local </dev/null
curl -vk https://10.10.20.10:8443/
```

### 4. Deploy hardened config
```bash
sudo cp config/nginx_after.conf /etc/nginx/nginx.conf
sudo nginx -t && sudo systemctl reload nginx
```

### 5. Run after scans (from client)
```bash
nmap --script ssl-enum-ciphers -p 8443 10.10.20.10
curl -vk https://10.10.20.10:8443/ 2>&1 | grep -E "SSL|Strict|TLS"
curl -sk -A "sqlmap/1.0" https://10.10.20.10:8443/
curl -sk https://10.10.20.10:8443/
```

---

## Deliverables

- `report.md` — full evidence pack report
- `config/` — before/after nginx configs + change log + cert info
- `evidence/before/` — scan outputs before hardening
- `evidence/after/` — scan outputs after hardening
- `tests/TEST_CARDS.md` — 8 test cards
- `appendix/failure_modes.md` — failure modes encountered

---

> ⚠️ Private keys are excluded from this repo (see .gitignore)
