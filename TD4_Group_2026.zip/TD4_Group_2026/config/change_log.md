# Change Log — TLS Hardening

| # | Directive | Before | After | NIST SP 800-52r2 ref | Reason |
|---|---|---|---|---|---|
| 1 | ssl_protocols | TLSv1 TLSv1.1 TLSv1.2 | TLSv1.2 TLSv1.3 | §3.1 — SHALL NOT support TLS 1.0/1.1 | TLS 1.0 and 1.1 have known vulnerabilities (POODLE, BEAST). Remove to eliminate downgrade risk. |
| 2 | ssl_ciphers | HIGH:MEDIUM:!aNULL | ECDHE+AESGCM:ECDHE+CHACHA20:!aNULL:!MD5:!RC4 | §3.3 — prefer AEAD cipher suites | MEDIUM includes CBC-based ciphers (no forward secrecy). New string allows only AEAD with ECDHE key exchange. |
| 3 | ssl_prefer_server_ciphers | off (default) | on | §3.3 | Forces server to select the strongest available cipher, preventing client from choosing weaker option. |
| 4 | HSTS header | absent | Strict-Transport-Security: max-age=300 | §3.5 — SHOULD enable HSTS | Tells browsers to always use HTTPS. Prevents SSL stripping attacks. max-age=300 is short for lab; use 31536000 in production. |
| 5 | User-agent filter | absent | if ($http_user_agent ~* "sqlmap\|nikto") return 403 | Edge hardening | Blocks common automated vulnerability scanners at the nginx layer before request is processed. |
| 6 | Rate limiting | absent | limit_req_zone rate=1r/s; burst=2 on /api | Availability protection | Limits requests per IP on /api endpoint to prevent flooding and brute-force attacks. |
