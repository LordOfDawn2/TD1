# TEST_CARDS.md — TD1 Network Baseline

---

## TD1-T01 : Client peut atteindre srv-web sur HTTP

**Claim :** client (10.10.10.10) peut accéder à srv-web (10.10.20.10) sur le port HTTP/80.

**Preconditions :**
- gw-fw actif avec IP forwarding activé
- srv-web démarré avec nginx actif
- client sur NH-LAN, srv-web sur NH-DMZ

**Config fragment :**
```
srv-web : nginx écoute sur 0.0.0.0:80
gw-fw   : route 10.10.10.0/24 via enp0s3, 10.10.20.0/24 via enp0s8
```

**Test method :**
- Positif : `curl http://10.10.20.10` → retourne HTML nginx ✓
- Négatif : couper nginx sur srv-web → `curl` doit échouer (connection refused)

**Telemetry :** réponse HTTP 200, body "Welcome to nginx!"

**Result :** ✅ PASS

**Artifacts :** evidence/nmap_srvweb.txt, tests/commands.txt §4

---

## TD1-T02 : Port inattendu sur srv-web fermé ou documenté comme risque

**Claim :** srv-web n'expose aucun port en dehors de 22 et 80 sur les ports 1-1000.

**Preconditions :**
- nmap disponible sur client
- srv-web accessible depuis NH-LAN via gw-fw

**Config fragment :**
```
nmap -sS -sV -p 1-1000 10.10.20.10
```

**Test method :**
- Positif : seuls 22/tcp et 80/tcp apparaissent open → ✓
- Négatif : tout autre port open → documenter comme risque dans report.md

**Telemetry :** 998 closed ports (reset), 2 open : 22/ssh, 80/http

**Result :** ✅ PASS — surface d'attaque minimale confirmée

**Artifacts :** evidence/nmap_srvweb.txt

---

## TD1-T03 : Capture baseline contient du trafic HTTP et ICMP

**Claim :** le fichier baseline.pcap contient au minimum du trafic HTTP (port 80) et ICMP généré depuis client.

**Preconditions :**
- sensor-ids en mode promiscuous sur NH-DMZ
- tcpdump lancé avant la génération de trafic

**Config fragment :**
```bash
sudo tcpdump -i enp0s3 -w /tmp/baseline.pcap -nn   # sur sensor-ids
curl http://10.10.20.10                              # sur client
ping -c 4 10.10.20.10                               # sur client
```

**Test method :**
- Positif : Wireshark filtre `http` → paquets visibles ; filtre `icmp` → 4 echo/reply
- Négatif : aucun paquet → vérifier interface et mode promiscuous

**Telemetry :** à compléter après capture (Part D)

**Result :** ⏳ EN ATTENTE — Part D

**Artifacts :** evidence/baseline.pcap (à produire)

---

## TD1-T04 : Diagramme réseau correspond à l'adressage observé

**Claim :** le diagramme diagram.svg reflète exactement les IPs, zones et services observés sur les 4 VMs.

**Preconditions :**
- Collecte complète des outputs `ip addr`, `ip route`, `ss -tulpn` sur les 4 VMs

**Config fragment :**
```
gw-fw    : 10.10.10.1 (enp0s3) / 10.10.20.1 (enp0s8)
client   : 10.10.10.10/24, GW 10.10.10.1
srv-web  : 10.10.20.10/24, GW 10.10.20.1, ports 22+80
sensor-ids: 10.10.20.50/24, GW 10.10.20.1, port 22
```

**Test method :**
- Positif : comparer chaque IP/service du diagramme avec les outputs collectés → correspondance exacte
- Négatif : toute divergence doit être documentée dans README.md (limitations)

**Telemetry :** outputs screenshots VMs (Part A)

**Result :** ✅ PASS — diagramme vérifié manuellement

**Artifacts :** diagram.svg, tests/commands.txt §1-2
