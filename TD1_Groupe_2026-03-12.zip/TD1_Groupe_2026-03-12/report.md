# TD1 — Report
**Module:** Network Hardening — ESILV 4ème année  
**Date:** 2026-03-12  
**Groupe:** _____

---

## Part D — Baseline Capture : Observations annotées

**Fichier pcap :** `/tmp/baseline.pcap`  
**Interface de capture :** `enp0s3` sur `sensor-ids` (10.10.20.50) — mode promiscuous  
**Durée :** ~12 secondes  
**Paquets capturés :** 24 paquets, 0 dropped  
**Trafic généré depuis :** `client` (10.10.10.10) → `curl http://10.10.20.10` + `ping -c 5 10.10.20.10`

---

### Observation O1 — Handshake TCP HTTP en clair

- **Time range :** 15:17:04.881 – 15:17:04.883
- **Flow reference :** F01 (LAN → DMZ, TCP/80)
- **What I saw :** TCP SYN depuis 10.10.10.10:41468 vers 10.10.20.10:80, suivi du SYN-ACK de srv-web, puis ACK du client. Handshake 3-way complet en ~2ms.
- **Why it matters :** Le handshake est visible en clair sur le réseau. N'importe quel hôte en mode promiscuous sur la DMZ (comme sensor-ids) peut intercepter l'intégralité de la session HTTP, y compris les credentials ou données sensibles transmises.
- **Proposed control :** Activer HTTPS/TLS sur nginx (TD3). Rediriger HTTP/80 vers HTTPS/443. Sans TLS, toute la session est lisible.
- **Evidence pointer :** baseline.pcap — paquets `Flags [S]`, `Flags [S.]`, `Flags [.]` à 15:17:04.881–883

---

### Observation O2 — Requête HTTP GET en clair + réponse 200 OK

- **Time range :** 15:17:04.882 – 15:17:04.884
- **Flow reference :** F01 (LAN → DMZ, TCP/80)
- **What I saw :** `HTTP: GET / HTTP/1.1` depuis client vers srv-web (length 75), réponse `HTTP/1.1 200 OK` depuis srv-web (length 862). La requête et la réponse complète sont visibles en clair dans le pcap.
- **Why it matters :** Le contenu HTTP est entièrement lisible — headers, corps de réponse, version du serveur (nginx 1.24.0). Un attaquant sur la DMZ peut faire du sniffing passif sans générer aucun trafic suspect.
- **Proposed control :** Configurer TLS sur srv-web (TD3). Masquer la version nginx dans les headers (`server_tokens off` dans nginx.conf). Ces deux actions éliminent l'information disclosure et le risque d'interception.
- **Evidence pointer :** baseline.pcap — `HTTP: GET / HTTP/1.1` à 15:17:04.882, `HTTP/1.1 200 OK` à 15:17:04.884

---

### Observation O3 — Trafic ARP entre gw-fw et srv-web

- **Time range :** 15:17:10.122 – 15:17:10.156
- **Flow reference :** F06 (ICMP / infrastructure)
- **What I saw :** Deux échanges ARP : `who-has 10.10.20.10 tell 10.10.20.1` (gw-fw demande le MAC de srv-web) et `who-has 10.10.20.1 tell 10.10.20.10` (srv-web demande le MAC de gw-fw). Réponses immédiates dans les deux sens.
- **Why it matters :** ARP est non authentifié. Un hôte malveillant sur la DMZ pourrait empoisonner les tables ARP (ARP spoofing) pour intercepter le trafic entre gw-fw et srv-web — attaque de type Man-in-the-Middle. sensor-ids voit tout ce trafic ARP, ce qui confirme son accès complet au segment DMZ.
- **Proposed control :** Activer Dynamic ARP Inspection (DAI) sur le switch DMZ (hors scope TD1, mais à documenter). Surveiller les réponses ARP inattendues via sensor-ids (TD4).
- **Evidence pointer :** baseline.pcap — `ARP Request/Reply` à 15:17:10.122–156

---

### Observation O4 — ICMP echo request/reply (ping LAN → DMZ)

- **Time range :** 15:17:12.061 – 15:17:16.084
- **Flow reference :** F06 (LAN → DMZ, ICMP)
- **What I saw :** 5 paires de paquets ICMP echo request (10.10.10.10 → 10.10.20.10) et echo reply (10.10.20.10 → 10.10.10.10), séquences 1 à 5. Tous reçus, 0% perte. RTT cohérent avec les mesures ping (~1ms inter-zone).
- **Why it matters :** ICMP est autorisé sans restriction entre LAN et DMZ. Il peut être utilisé pour de la reconnaissance réseau (ping sweep) ou de l'exfiltration de données (ICMP tunneling). La présence de ICMP non filtré élargit la surface d'attaque.
- **Proposed control :** Limiter ICMP sur gw-fw : autoriser uniquement echo-request/reply à destination des hôtes connus (10.10.20.10, 10.10.20.50). Bloquer les autres types ICMP (redirect, timestamp). À implémenter en TD2.
- **Evidence pointer :** baseline.pcap — `ICMP echo request/reply` id 4, seq 1–5 à 15:17:12–16

---

### Observation O5 — Fermeture TCP propre (FIN/ACK)

- **Time range :** 15:17:04.889 – 15:17:04.891
- **Flow reference :** F01 / F07 (trafic retour stateful)
- **What I saw :** Séquence de fermeture TCP : `Flags [F.]` depuis client (seq 76), `Flags [F.]` depuis srv-web (seq 863), ACK final des deux côtés. Fermeture propre en 4 paquets.
- **Why it matters :** La fermeture propre confirme que le firewall laisse passer le trafic retour (stateful implicite). Cependant, l'absence de règles iptables vérifiées sur gw-fw signifie qu'on ne sait pas si ce comportement est contrôlé ou par défaut (ACCEPT all). Une politique ACCEPT par défaut est un risque majeur.
- **Proposed control :** Auditer et configurer les règles iptables sur gw-fw (TD2) : politique par défaut DROP, avec règles ACCEPT explicites pour les flux F01–F06. Vérifier que le suivi de connexion (conntrack) est actif.
- **Evidence pointer :** baseline.pcap — `Flags [F.]` à 15:17:04.889–891

---

## Part E — Risk List & Quick Wins

### Top 10 Risques

| # | Risque | Impact | Facilité d'exploitation | Évidence |
|---|--------|--------|------------------------|----------|
| R01 | HTTP sans TLS — trafic en clair | Élevé | Facile (sniffing passif) | O1, O2 — curl + pcap |
| R02 | SSH/22 exposé sur 0.0.0.0 (srv-web + sensor-ids) | Élevé | Moyen (brute force, CVE) | nmap, ss -tulpn |
| R03 | Politique firewall gw-fw inconnue (ACCEPT par défaut ?) | Élevé | Facile si ACCEPT all | O5 — trafic retour non filtré |
| R04 | Version nginx divulguée dans headers HTTP | Moyen | Facile (curl -I) | nmap -sV : nginx 1.24.0 |
| R05 | Version OpenSSH divulguée (banner SSH) | Moyen | Facile (connexion TCP/22) | nmap -sV : OpenSSH 9.6p1 |
| R06 | ARP spoofing possible sur DMZ (pas de DAI) | Élevé | Moyen | O3 — ARP non authentifié |
| R07 | ICMP non filtré LAN↔DMZ (tunneling possible) | Moyen | Moyen | O4 — ping sweep possible |
| R08 | Page nginx par défaut exposée (information disclosure) | Faible | Facile | curl : "Welcome to nginx!" |
| R09 | Pas de séparation trafic admin / applicatif sur srv-web | Moyen | Moyen | SSH et HTTP sur même IP |
| R10 | sensor-ids SSH exposé sans restriction IP source | Élevé | Moyen | ss -tulpn : 0.0.0.0:22 |

---

### Top 5 Quick Wins

| # | Action | Impact | Coût | TD cible |
|---|--------|--------|------|----------|
| QW1 | Configurer TLS/HTTPS sur nginx + rediriger HTTP → HTTPS | Élevé | Faible | TD3 |
| QW2 | Règles iptables sur gw-fw : politique DROP par défaut + ACCEPT explicites | Élevé | Faible | TD2 |
| QW3 | Restreindre SSH/22 par IP source (srv-web + sensor-ids) : `AllowUsers` + règle firewall | Élevé | Faible | TD2 |
| QW4 | Désactiver server_tokens nginx (`server_tokens off`) + masquer banner SSH | Moyen | Très faible | TD3 |
| QW5 | Filtrer ICMP sur gw-fw : autoriser uniquement echo-request/reply vers hôtes connus | Moyen | Faible | TD2 |
