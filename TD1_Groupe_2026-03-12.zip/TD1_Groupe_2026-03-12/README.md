# TD1 — Network Baseline for Hardening

**Module:** Network Hardening — ESILV 4ème année  
**Date:** 2025-__-__  
**Groupe:** _____

---

## Membres et rôles

| Membre | Rôle |
|---|---|
| _____ | Cartographie réseau / mapping |
| _____ | Flow matrix & validation |
| _____ | Capture pcap & annotations |
| _____ | Risk list & rédaction rapport |

---

## Topologie du lab

| VM | Rôle | Zone | IP | Gateway |
|---|---|---|---|---|
| gw-fw | Firewall / Trust Boundary | NH-LAN + NH-DMZ | 10.10.10.1 / 10.10.20.1 | — (routeur) |
| client | Scanner / collecte preuves | NH-LAN | 10.10.10.10/24 | 10.10.10.1 |
| srv-web | Cible : HTTP, SSH | NH-DMZ | 10.10.20.10/24 | 10.10.20.1 |
| sensor-ids | Capture promiscuous, IDS | NH-DMZ | 10.10.20.50/24 | 10.10.20.1 |

**Réseaux VirtualBox :**
- `NH-LAN` : 10.10.10.0/24 — zone clients
- `NH-DMZ` : 10.10.20.0/24 — zone services
- Trust boundary : `gw-fw` (enp0s3 → LAN, enp0s8 → DMZ)

---

## Ce qui a été testé

- Collecte d'informations système sur les 4 VMs (`hostname`, `ip addr`, `ip route`, `ss -tulpn`)
- Construction du diagramme réseau (zones, assets, frontière de confiance)
- Rédaction de la flow matrix (flux autorisés + DENY par défaut)
- Validation de la joignabilité depuis `client` vers `srv-web` (nmap, curl)
- Capture baseline pcap sur `sensor-ids` (mode promiscuous)
- Identification des risques et quick wins

---

## Limitations connues

- HTTPS/443 non détecté sur `srv-web` — à confirmer si configuré
- `gw-fw` : pas de règles de firewall actives vérifiées (à faire en TD2)
- Capture pcap limitée à la durée de la session (5–10 min)
- NAT de `client` à désactiver avant les tests (eth1 DOWN)
