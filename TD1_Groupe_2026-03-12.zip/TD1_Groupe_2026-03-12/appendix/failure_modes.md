# Failure Modes — TD1

## FM01 — SCP vers sensor-ids impossible
**Problème :** SSH inactif sur sensor-ids (service disabled). SCP bloque à la connexion TCP.
**Symptôme :** ssh -v bloque à "Connecting to 10.10.20.50 port 22"
**Résolution :** sudo systemctl start ssh sur sensor-ids. Ou afficher le pcap directement avec sudo tcpdump -r /tmp/baseline.pcap -nn.

## FM02 — tcpdump Permission denied sur /tmp/baseline.pcap
**Problème :** Fichier créé avec sudo, appartient à root.
**Symptôme :** tcpdump: /tmp/baseline.pcap: Permission denied
**Résolution :** sudo rm /tmp/baseline.pcap puis relancer avec sudo.

## FM03 — Capture avec trop peu de paquets
**Problème :** tcpdump lancé sans générer de trafic depuis client en parallèle.
**Résolution :** Lancer tcpdump en arrière-plan avec & puis générer trafic depuis client avant pkill.
