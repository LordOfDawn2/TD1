# TEST_CARDS.md — TD5 Test Plan

---

## TD5-T01 — SSH password authentication disabled

**Claim:** Password-based SSH login is rejected on siteB-srv.

**Positive test:**
```bash
ssh -i ~/.ssh/id_td5 admin1@10.10.20.10 "echo SSH_KEY_OK"
# Expected: SSH_KEY_OK
```

**Negative test:**
```bash
ssh -o PubkeyAuthentication=no admin1@10.10.20.10
# Expected: Permission denied (publickey).
```

**Evidence:** `evidence/ssh_tests.txt`, `evidence/authlog_excerpt.txt`

---

## TD5-T02 — Root login via SSH disabled

**Claim:** Direct SSH login as root is blocked by `PermitRootLogin no`.

**Positive test:** N/A

**Negative test:**
```bash
ssh -i ~/.ssh/id_td5 root@10.10.20.10
# Expected: Permission denied (publickey).
```

**Evidence:** `evidence/ssh_tests.txt`

---

## TD5-T03 — AllowUsers restricts SSH to admin1 only

**Claim:** `AllowUsers admin1` prevents any other user from connecting.

**Positive test:**
```bash
ssh -i ~/.ssh/id_td5 admin1@10.10.20.10
# Expected: connection established
```

**Negative test:**
```bash
ssh -i ~/.ssh/id_td5 user@10.10.20.10
# Expected: Permission denied — not listed in AllowUsers
```

**Evidence:** `evidence/authlog_excerpt.txt`

---

## TD5-T04 — SSH audit trail in auth.log

**Claim:** `/var/log/auth.log` records accepts and denies with username, method, and source IP.

**Positive test:**
```bash
sudo tail -n 50 /var/log/auth.log | grep "Accepted publickey"
# Expected: Accepted publickey for admin1 from 10.10.10.10
```

**Negative test:**
```bash
sudo tail -n 50 /var/log/auth.log | grep "not allowed"
# Expected: User root from 10.10.10.10 not allowed because not listed in AllowUsers
```

**Evidence:** `evidence/authlog_excerpt.txt`

---

## TD5-T05 — IKEv2 tunnel establishes successfully

**Claim:** `ipsec statusall` shows IKE_SA ESTABLISHED and CHILD_SA INSTALLED on both gateways.

**Positive test:**
```bash
# On both gateways
sudo ipsec statusall | grep -E "ESTABLISHED|INSTALLED"
# Expected: ESTABLISHED + INSTALLED, TUNNEL
```

**Negative test:** Block UDP 500 on siteA-gw → tunnel fails to negotiate (no IKE exchange).

**Evidence:** `evidence/ipsec_status.txt`

---

## TD5-T06 — Traffic passes through IPsec tunnel

**Claim:** Ping from siteA-client to siteB-srv traverses the IPsec tunnel (4/4 packets, 0% loss).

**Positive test:**
```bash
# From siteA-client
ping -c 4 10.10.20.10
# Expected: 4 packets transmitted, 4 received, 0% packet loss
```

**Negative test:** Without active tunnel → ping timeout (no alternative route).

**Evidence:** `evidence/tunnel_ping.txt`

---

## TD5-T07 — Traffic is encrypted (ESP visible, no cleartext)

**Claim:** The WAN segment reveals only ESP packets — no cleartext ICMP.

**Positive test:**
```bash
# On siteA-gw during ping from siteA-client
sudo tcpdump -i enp0s8 -c 20 'udp port 500 or udp port 4500 or esp'
# Expected: only ESP packets — no ICMP in cleartext
```

**Negative test:** If tunnel is down → cleartext ICMP visible on WAN.

**Evidence:** `evidence/tunnel_ping.txt` (tcpdump section)

---

## TD5-T08 — Tunnel scoped to LAN <-> DMZ only

**Claim:** IPsec config limits traffic to 10.10.10.0/24 <-> 10.10.20.0/24. No 0.0.0.0/0 tunnelling.

**Positive test:**
```bash
grep -E "leftsubnet|rightsubnet" /etc/ipsec.conf
# Expected:
# leftsubnet=10.10.10.0/24
# rightsubnet=10.10.20.0/24
```

**Negative test:** Traffic to addresses outside these subnets is NOT tunnelled (routes not covered by SPD).

**Evidence:** `config/ipsec_siteA.conf`, `config/ipsec_siteB.conf`
