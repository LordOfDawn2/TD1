# Appendix — Failure Modes

| ID | Failure | Symptom | Fix Applied |
|---|---|---|---|
| FM-01 | SSH lockout after config change | Cannot connect after sshd_config edit | Always keep a console open; run `sshd -t` before restart |
| FM-02 | IKEv2 fails to negotiate | `ipsec statusall` shows CONNECTING, never ESTABLISHED | Verify proposals match exactly on both sides; check secrets |
| FM-03 | UDP 500/4500 blocked | No IKE packets reach the peer | `tcpdump udp port 500`; check firewall rules on gateways |
| FM-04 | VPN up but no traffic | Ping fails despite ESTABLISHED SA | Check routes, `ip_forward=1`, MTU (ESP overhead ~50B) |
| FM-05 | Proposal mismatch | NO_PROPOSAL_CHOSEN in logs | Align `ike=` and `esp=` strings exactly on both gateways |
| FM-06 | cloud-init SSH override | PasswordAuthentication stays enabled despite sshd_config | Fix `/etc/ssh/sshd_config.d/50-cloud-init.conf` — set `PasswordAuthentication no` |
| FM-07 | Stale / conflicting IPs on NICs | Multiple IPs on same interface (e.g. 10.10.20.50 and 10.10.20.1) | `sudo ip addr flush dev <iface>` then reassign; persist via netplan |
| FM-08 | strongSwan service not found | `systemctl restart strongswan-starter` fails | Install `charon-systemd` package alongside `strongswan` |
| FM-09 | Routes missing after reboot | IPs present but cross-site ping fails | Persist routes in `/etc/netplan/*.yaml` under `routes:` key |
