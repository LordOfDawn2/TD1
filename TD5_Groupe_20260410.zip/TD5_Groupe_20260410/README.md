# TD5 — Secure Remote Access: SSH Hardening + Site-to-Site IPsec VPN (IKEv2)

**Module:** Network Hardening — ESILV 4th year  
**Date:** April 10, 2026  
**Author:** Adrien (Promo 2026)

---

## Topology

```
[siteA-client]──────[siteA-gw]════════WAN════════[siteB-gw]──────[siteB-srv]
 10.10.10.10         10.10.10.1    10.10.99.x    10.10.20.1       10.10.20.10
 NH-LAN              NH-LAN/WAN    NH-WAN        NH-WAN/DMZ       NH-DMZ
```

| VM | TD5 Role | IPs |
|---|---|---|
| `gw-fw` | siteA-gw | 10.10.10.1 / 10.10.99.1 |
| `client` (Kali) | siteA-client | 10.10.10.10 |
| `srv-web` | siteB-srv (bastion) | 10.10.20.10 |
| `sensor-ids` | siteB-gw | 10.10.20.1 / 10.10.99.2 |

---

## How to Reproduce

### 1. VirtualBox NIC setup (from host)
```bash
VBoxManage modifyvm "gw-fw" --nic2 intnet --intnet2 "NH-WAN"
VBoxManage modifyvm "sensor-ids" --nic2 intnet --intnet2 "NH-WAN"
```

### 2. IP configuration — siteA-gw
```bash
sudo ip addr add 10.10.99.1/24 dev enp0s8
sudo ip link set enp0s8 up
sudo sysctl -w net.ipv4.ip_forward=1
sudo ip route add 10.10.20.0/24 via 10.10.99.2
```

### 3. IP configuration — siteB-gw
```bash
sudo ip addr add 10.10.20.1/24 dev enp0s3
sudo ip addr add 10.10.99.2/24 dev enp0s8
sudo ip link set enp0s3 up && sudo ip link set enp0s8 up
sudo sysctl -w net.ipv4.ip_forward=1
sudo ip route add 10.10.10.0/24 via 10.10.99.1
```

### 4. SSH hardening — siteB-srv
```bash
sudo useradd -m -s /bin/bash admin1
# On siteA-client:
ssh-keygen -t ed25519 -f ~/.ssh/id_td5 -C "admin1@td5"
ssh-copy-id -i ~/.ssh/id_td5.pub admin1@10.10.20.10
# Apply config/sshd_config_excerpt.txt to /etc/ssh/sshd_config
# Apply same PasswordAuthentication no to /etc/ssh/sshd_config.d/50-cloud-init.conf
sudo sshd -t && sudo systemctl restart ssh
```

### 5. IPsec VPN — both gateways
```bash
sudo apt install -y strongswan charon-systemd libcharon-extra-plugins
# Deploy config/ipsec_siteA.conf (or siteB) to /etc/ipsec.conf
# Deploy ipsec.secrets (with real PSK) to /etc/ipsec.secrets
sudo systemctl enable strongswan-starter strongswan
sudo systemctl restart strongswan-starter
sudo ipsec statusall
```

---

## Security notes
- PSK used for lab only — use X.509 certificates in production
- No secrets committed — see `config/ipsec.secrets` for placeholder
